package com.cognizant.ComplianceAndAuditService.Response;

import com.cognizant.ComplianceAndAuditService.Entity.Audit;
import lombok.*;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditResponse {

    private Long auditId;
    private Long officerId;
    private String scope;
    private String findings;
    private Audit.AuditStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
