package com.cognizant.authentication.externalService;

import com.cognizant.authentication.dto.RegisterRequestDto;
import com.cognizant.authentication.dto.RegisterResponseDto;
import com.cognizant.authentication.dto.UserDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "user-service")
public interface UserServiceClient {

    @PostMapping("/users/register")
    RegisterResponseDto createUser(@RequestBody RegisterRequestDto registerRequestDto);

    @GetMapping("/users/email/{email}")
    UserDto findByEmail(@PathVariable String email);

}
