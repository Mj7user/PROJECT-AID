package com.cognizant.RegistrationAndManagement.service;

import com.cognizant.RegistrationAndManagement.entity.Citizen;
import com.cognizant.RegistrationAndManagement.request.CitizenRequest;
import com.cognizant.RegistrationAndManagement.response.CitizenResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface CitizenService {

    CitizenResponse registerCitizen(CitizenRequest request);

    CitizenResponse getCitizenById(Long id);

    CitizenResponse updateCitizen(Long id, CitizenRequest request);

    Page<CitizenResponse> getAllCitizens(Pageable pageable);

    Page<CitizenResponse> searchCitizens(String search, Pageable pageable);

    // ✅ THIS METHOD WAS MISSING EARLIER
    Page<CitizenResponse> getCitizensByStatus(
            Citizen.CitizenStatus status,
            Pageable pageable
    );

    void updateCitizenStatus(Long id, Citizen.CitizenStatus status);
}