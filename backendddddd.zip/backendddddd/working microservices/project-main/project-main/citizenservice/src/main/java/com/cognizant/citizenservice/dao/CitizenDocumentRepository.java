package com.cognizant.citizenservice.dao;

import com.cognizant.citizenservice.entity.CitizenDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CitizenDocumentRepository extends JpaRepository<CitizenDocument, Long> {
    List<CitizenDocument> findByCitizenId(Long citizenId);
}
