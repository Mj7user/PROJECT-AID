package com.cognizant.civicaid.authenticationService.service;

import com.cognizant.civicaid.authenticationService.dto.LoginRequestDto;
import com.cognizant.civicaid.authenticationService.dto.LoginResponseDto;
import com.cognizant.civicaid.authenticationService.dto.RegisterRequestDto;
import com.cognizant.civicaid.authenticationService.dto.RegisterResponseDto;

public interface AuthService {

    RegisterResponseDto createUsers(RegisterRequestDto registerRequestDto);
    LoginResponseDto login(LoginRequestDto loginRequestDto);
}
