package com.cognizant.civicaid.authenticationService.service;

import com.cognizant.civicaid.authenticationService.dto.*;
import com.cognizant.civicaid.authenticationService.externalService.UserServiceClient;
import com.cognizant.civicaid.authenticationService.security.jwt.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserServiceClient userServiceClient;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider jwtTokenProvider;

    @Override
    public RegisterResponseDto createUsers(RegisterRequestDto registerRequestDto) {

        registerRequestDto.setPassword(
                passwordEncoder.encode(registerRequestDto.getPassword()));

        return userServiceClient.createUser(registerRequestDto);
    }

    @Override
    public LoginResponseDto login(LoginRequestDto loginRequestDto){

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequestDto.getEmail(), loginRequestDto.getPassword())
        );

        UserDetails userDetails=(UserDetails) authentication.getPrincipal();

//        UserDto u=userServiceClient.findByEmail("aman@gmail.com");

//        System.out.println(u.getRole());

        String token=jwtTokenProvider.generateToken(userDetails);

        return LoginResponseDto.builder()
                .email(authentication.getName())
                .token(token)
                .role(userDetails.getAuthorities()
                        .iterator()
                        .next()
                        .getAuthority())
                .build();
    }
}
