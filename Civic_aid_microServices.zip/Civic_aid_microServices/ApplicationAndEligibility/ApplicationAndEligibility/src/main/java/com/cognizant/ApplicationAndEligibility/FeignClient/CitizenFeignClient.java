package com.cognizant.ApplicationAndEligibility.FeignClient;

import com.cognizant.ApplicationAndEligibility.response.CitizenResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient (name = "citizen-service")
public interface CitizenFeignClient {

    @GetMapping("/citizens/{id}")
    CitizenResponse getCitizenById(@PathVariable Long id);
}