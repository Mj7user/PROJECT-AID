package com.cognizant.DisbursementAndPaymentService.Request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class DisbursementRequest {
    @NotNull private Long applicationId;
    @NotNull private Long citizenId;
    @NotNull private Long programId;
    @NotNull @Positive private BigDecimal amount;
    private String remarks;
}