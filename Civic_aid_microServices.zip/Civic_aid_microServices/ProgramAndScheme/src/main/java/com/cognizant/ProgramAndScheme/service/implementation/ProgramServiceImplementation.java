package com.cognizant.ProgramAndScheme.service.implementation;

import com.cognizant.ProgramAndScheme.dto.request.ProgramRequest;
import com.cognizant.ProgramAndScheme.dto.response.ProgramResponse;
import com.cognizant.ProgramAndScheme.entity.Program;
import com.cognizant.ProgramAndScheme.exception.ResourceNotFoundException;
import com.cognizant.ProgramAndScheme.repository.ProgramRepository;
import com.cognizant.ProgramAndScheme.service.ProgramService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ProgramServiceImplementation implements ProgramService {

    private final ProgramRepository programRepository;

    @Override
    @Transactional
    public ProgramResponse createProgram(ProgramRequest request) {

        Program program = Program.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .startDate(request.getStartDate())
                .endDate(request.getEndDate())
                .budget(request.getBudget())
                .status(request.getStatus())
                .build();

        return map(programRepository.save(program));
    }

    @Override
    public ProgramResponse getProgramById(Long id) {
        Program program = programRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Program", id));

        return map(program);
    }

    @Override
    public Page<ProgramResponse> getAllPrograms(Pageable pageable) {
        return programRepository.findAll(pageable)
                .map(this::map);
    }

    private ProgramResponse map(Program p) {
        return ProgramResponse.builder()
                .programId(p.getProgramId())
                .title(p.getTitle())
                .description(p.getDescription())
                .startDate(p.getStartDate())
                .endDate(p.getEndDate())
                .budget(p.getBudget())
                .status(p.getStatus())
                .createdAt(p.getCreatedAt())
                .updatedAt(p.getUpdatedAt())
                .build();
    }
}
