package com.cognizant.programservice.dao;
import com.cognizant.programservice.entity.Program; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface ProgramRepository extends JpaRepository<Program, Long> { List<Program> findByStatus(Program.ProgramStatus status); }
