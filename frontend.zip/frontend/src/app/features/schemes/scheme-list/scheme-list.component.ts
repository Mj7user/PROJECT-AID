import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ProgramService } from '../../../core/services/program.service';
import { AuthService } from '../../../core/services/auth.service';
import { SchemeResponse } from '../../../core/models/program.model';
import { Role } from '../../../core/models/role.enum';
import { LoaderComponent } from '../../../shared/components/loader/loader.component';

@Component({
  selector: 'app-scheme-list',
  standalone: true,
  imports: [CommonModule, FormsModule, LoaderComponent],
  templateUrl: './scheme-list.component.html',
  styleUrl: './scheme-list.component.css'
})
export class SchemeListComponent implements OnInit {
  private programService = inject(ProgramService);
  private authService = inject(AuthService);
  private router = inject(Router);

  allSchemes: SchemeResponse[] = [];
  filteredSchemes: SchemeResponse[] = [];
  loading = true;
  searchTerm = '';
  filterStatus = '';

  get canCreate(): boolean {
    return this.authService.hasRole(Role.PROGRAM_MANAGER, Role.ADMINISTRATOR);
  }

  ngOnInit(): void { this.loadSchemes(); }

  loadSchemes(): void {
    this.programService.getAllSchemes().subscribe({
      next: schemes => {
        this.allSchemes = schemes;
        this.filteredSchemes = schemes;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }

  applyFilters(): void {
    this.filteredSchemes = this.allSchemes.filter(s => {
      const matchSearch = !this.searchTerm ||
        s.title.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        (s.description || '').toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        (s.eligibilityCriteria || '').toLowerCase().includes(this.searchTerm.toLowerCase());
      const matchStatus = !this.filterStatus || s.status === this.filterStatus;
      return matchSearch && matchStatus;
    });
  }

  viewScheme(id: number): void { this.router.navigate(['/schemes', id]); }
  createScheme(): void { this.router.navigate(['/schemes/create']); }

  getStatusClass(status: string): string {
    return status === 'ACTIVE' ? 'badge-success' : 'badge-neutral';
  }
}
