package com.cognizant.civicaid.userservice.dto;

import com.cognizant.civicaid.userservice.entity.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {

    private String email;
    private User.Role role;
    private String password;
}
