package com.cognizant.programservice.service;

import com.cognizant.programservice.dto.SchemeRequestDto;
import com.cognizant.programservice.dto.SchemeResponseDto;
import com.cognizant.programservice.entity.Program;
import com.cognizant.programservice.entity.Scheme;
import com.cognizant.programservice.exception.ResourceNotFoundException;
import com.cognizant.programservice.dao.ProgramRepository;
import com.cognizant.programservice.dao.SchemeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SchemeServiceImpl implements SchemeService {

    private final SchemeRepository schemeRepository;
    private final ProgramRepository programRepository;

    @Override
    @Transactional
    public SchemeResponseDto createScheme(SchemeRequestDto request) {

        Program program = programRepository.findById(request.getProgramId())
                .orElseThrow(() ->
                        new ResourceNotFoundException("Program", request.getProgramId()));

        Scheme scheme = Scheme.builder()
                .program(program)
                .title(request.getTitle())
                .description(request.getDescription())
                .budget(request.getBudget())
                .eligibilityCriteria(request.getEligibilityCriteria())
                .status(request.getStatus())
                .build();

        return map(schemeRepository.save(scheme));
    }

    @Override
    public SchemeResponseDto getSchemeById(Long id) {
        return map(
                schemeRepository.findById(id)
                        .orElseThrow(() ->
                                new ResourceNotFoundException("Scheme", id))
        );
    }

    @Override
    public Page<SchemeResponseDto> getAllSchemes(Pageable pageable) {
        return schemeRepository.findAll(pageable)
                .map(this::map);
    }

    @Override
    public List<SchemeResponseDto> getSchemesByProgram(Long programId) {
        return schemeRepository.findByProgram_ProgramId(programId)
                .stream()
                .map(this::map)
                .toList();
    }

    @Override
    @Transactional
    public SchemeResponseDto updateScheme(Long id, SchemeRequestDto request) {

        Scheme scheme = schemeRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Scheme", id));

        Program program = programRepository.findById(request.getProgramId())
                .orElseThrow(() ->
                        new ResourceNotFoundException("Program", request.getProgramId()));

        scheme.setProgram(program);
        scheme.setTitle(request.getTitle());
        scheme.setDescription(request.getDescription());
        scheme.setBudget(request.getBudget());
        scheme.setEligibilityCriteria(request.getEligibilityCriteria());
        scheme.setStatus(request.getStatus());

        return map(schemeRepository.save(scheme));
    }

    @Override
    @Transactional
    public void updateSchemeStatus(Long id, Scheme.SchemeStatus status) {
        Scheme scheme = schemeRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Scheme", id));

        scheme.setStatus(status);
        schemeRepository.save(scheme);
    }

    @Override
    @Transactional
    public void deleteScheme(Long id) {
        schemeRepository.delete(
                schemeRepository.findById(id)
                        .orElseThrow(() ->
                                new ResourceNotFoundException("Scheme", id))
        );
    }


    private SchemeResponseDto map(Scheme s) {
        return SchemeResponseDto.builder()
                .schemeId(s.getSchemeId())
                .programId(s.getProgram().getProgramId())
                .programTitle(s.getProgram().getTitle())
                .title(s.getTitle())
                .description(s.getDescription())
                .budget(s.getBudget())
                .eligibilityCriteria(s.getEligibilityCriteria())
                .status(s.getStatus())
                .createdAt(s.getCreatedAt())
                .updatedAt(s.getUpdatedAt())
                .build();
    }
}
