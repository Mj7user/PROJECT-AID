package com.cognizant.Report.repository;

import com.cognizant.Report.entity.ApplicationReport;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApplicationRepo
        extends JpaRepository<ApplicationReport, Long> {

    long countByStatus(ApplicationReport.ApplicationStatus status);

    long countByProgramId(Long programId);
}