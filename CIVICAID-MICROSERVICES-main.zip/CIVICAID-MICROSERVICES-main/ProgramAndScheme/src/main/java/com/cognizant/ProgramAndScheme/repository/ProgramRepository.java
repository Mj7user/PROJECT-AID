package com.cognizant.ProgramAndScheme.repository;



import com.cognizant.ProgramAndScheme.entity.Program;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ProgramRepository extends JpaRepository<Program, Long> {
    boolean existsByTitle(String title);
    Optional<Program> findByTitle(String title);
}