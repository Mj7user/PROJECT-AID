import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  collapsed = false;
  userEmail = '';
  userRole = '';

  navItems: { icon: string; label: string; route: string; roles?: string[] }[] = [];

  constructor(public authService: AuthService, private router: Router) {}

  ngOnInit() {
    const user = this.authService.getCurrentUser();
    this.userEmail = user?.email || '';
    this.userRole = user?.role || '';

    this.navItems = [
      { icon: '📊', label: 'Dashboard', route: '/dashboard' },
      { icon: '📋', label: 'Programs', route: '/programs' },
      { icon: '📄', label: 'Schemes', route: '/schemes' },
      { icon: '📝', label: 'Applications', route: '/applications' },
      { icon: '👥', label: 'Citizens', route: '/citizens' },
      { icon: '💰', label: 'Disbursements', route: '/disbursements' },
      { icon: '✅', label: 'Compliance', route: '/compliance' },
      { icon: '🔍', label: 'Audits', route: '/audits' },
      { icon: '👤', label: 'Users', route: '/users', roles: ['ADMINISTRATOR', 'WELFARE_OFFICER', 'PROGRAM_MANAGER'] },
      { icon: '🔔', label: 'Notifications', route: '/notifications' }
    ];
  }

  isVisible(item: { roles?: string[] }): boolean {
    if (!item.roles) return true;
    return this.authService.hasRole(...item.roles);
  }

  toggleSidebar() {
    this.collapsed = !this.collapsed;
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  getRoleDisplay(): string {
    return this.userRole.replace(/_/g, ' ');
  }
}
