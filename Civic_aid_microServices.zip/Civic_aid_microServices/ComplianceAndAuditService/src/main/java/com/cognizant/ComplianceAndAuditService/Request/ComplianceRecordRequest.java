package com.cognizant.ComplianceAndAuditService.Request;

import com.cognizant.ComplianceAndAuditService.Entity.ComplianceRecord;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ComplianceRecordRequest {

    @NotNull
    private Long entityId;

    @NotNull
    private ComplianceRecord.EntityType entityType;

    @NotNull
    private ComplianceRecord.ComplianceResult result;

    private String notes;
}