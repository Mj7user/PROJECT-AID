export type Gender = 'MALE' | 'FEMALE' | 'OTHER';
export type CitizenStatus = 'PENDING' | 'VERIFIED' | 'REJECTED' | 'SUSPENDED';

export interface CitizenRequest {
  userId: number;
  name: string;
  dob: string;
  gender?: Gender;
  address?: string;
  contactInfo?: string;
}

export interface CitizenResponse {
  citizenId: number;
  name: string;
  dob: string;
  gender: Gender;
  address: string;
  contactInfo: string;
  status: CitizenStatus;
  userId: number;
  createdAt: string;
  updatedAt: string;
}
