export type ApplicationStatus = 'SUBMITTED' | 'UNDER_REVIEW' | 'ELIGIBLE' | 'INELIGIBLE' | 'APPROVED' | 'REJECTED' | 'DISBURSED' | 'CLOSED';
export type CheckResult = 'ELIGIBLE' | 'INELIGIBLE' | 'PENDING_DOCUMENTS' | 'FURTHER_REVIEW';

export interface WelfareApplicationRequest {
  citizenId: number;
  programId: number;
  schemeId?: number;
  remarks?: string;
}

export interface WelfareApplicationResponse {
  applicationId: number;
  citizenId: number;
  programId: number;
  schemeId: number;
  submittedDate: string;
  status: ApplicationStatus;
  remarks: string;
  updatedAt: string;
}

export interface EligibilityCheckRequest {
  applicationId: number;
  officerId: number;
  result: CheckResult;
  notes?: string;
}

export interface EligibilityCheckResponse {
  checkId: number;
  applicationId: number;
  officerId: number;
  result: CheckResult;
  date: string;
  notes: string;
}
