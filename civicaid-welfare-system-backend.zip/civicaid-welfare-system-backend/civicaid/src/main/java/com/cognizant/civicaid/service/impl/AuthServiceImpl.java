
package com.cognizant.civicaid.service.impl;

import com.cognizant.civicaid.dto.request.AuthRequest;
import com.cognizant.civicaid.dto.response.LoginResponse;
import com.cognizant.civicaid.dto.response.RegisterResponse;
import com.cognizant.civicaid.dto.response.UserResponse;
import com.cognizant.civicaid.entity.User;
import com.cognizant.civicaid.exception.BusinessException;
import com.cognizant.civicaid.exception.DuplicateResourceException;
import com.cognizant.civicaid.exception.ResourceNotFoundException;
import com.cognizant.civicaid.repository.UserRepository;
import com.cognizant.civicaid.security.jwt.JwtTokenProvider;
import com.cognizant.civicaid.service.AuditLogService;
import com.cognizant.civicaid.service.AuthService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;
    private final AuthenticationManager authenticationManager;
    private final AuditLogService auditLogService;

    @Override
    @Transactional
    public LoginResponse login(AuthRequest.Login request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        String accessToken = jwtTokenProvider.generateAccessToken(request.getEmail());

        log.info("User logged in: {}", request.getEmail());
        auditLogService.log(user.getUserId(), "LOGIN", "AUTH",
                "User logged in successfully", null);

        return LoginResponse.builder()
                .accessToken(accessToken)
                .user(mapToUserResponse(user))
                .build();
    }

    @Override
    @Transactional
    public RegisterResponse register(AuthRequest.Register request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email already registered: " + request.getEmail());
        }

        // Self-registration is restricted to CITIZEN only.
        // All privileged roles (WELFARE_OFFICER, PROGRAM_MANAGER, etc.) must be
        // created by an ADMINISTRATOR via POST /users.
        User.Role role;
        try {
            role = User.Role.valueOf(request.getRole().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new BusinessException("Invalid role: " + request.getRole());
        }
        if (role != User.Role.CITIZEN) {
            throw new BusinessException(
                    "Self-registration is only allowed for the CITIZEN role. " +
                            "Privileged accounts must be created by an Administrator.");
        }

        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .phone(request.getPhone())
                .role(role)
                .status(User.UserStatus.ACTIVE)
                .build();

        user = userRepository.save(user);
        log.info("New user registered: {}", request.getEmail());
        auditLogService.log(user.getUserId(), "REGISTER", "AUTH",
                "New account registered with role: " + role.name(), null);

        //String accessToken = jwtTokenProvider.generateAccessToken(user.getEmail());
        //String refreshToken = jwtTokenProvider.generateRefreshToken(user.getEmail());

        return RegisterResponse.builder()
                .user(mapToUserResponse(user))
                .build();
    }


    @Override
    public void logout(String token) {
        // Stateless JWT — client discards token; add token blacklist here if needed
        log.info("User logged out");
    }

    private UserResponse mapToUserResponse(User user) {
        return UserResponse.builder()
                .userId(user.getUserId())
                .name(user.getName())
                .email(user.getEmail())
                .phone(user.getPhone())
                .role(user.getRole())
                .status(user.getStatus())
                .createdAt(user.getCreatedAt())
                .updatedAt(user.getUpdatedAt())
                .build();
    }
}
