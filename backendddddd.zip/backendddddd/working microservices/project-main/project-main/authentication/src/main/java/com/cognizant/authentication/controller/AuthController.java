package com.cognizant.authentication.controller;

import com.cognizant.authentication.dto.LoginRequestDto;
import com.cognizant.authentication.dto.LoginResponseDto;
import com.cognizant.authentication.dto.RegisterRequestDto;
import com.cognizant.authentication.dto.RegisterResponseDto;
import com.cognizant.authentication.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<RegisterResponseDto>registerUser(
            @Valid @RequestBody RegisterRequestDto registerRequestDto){

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(authService.createUsers(registerRequestDto));
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponseDto>login(
            @Valid @RequestBody LoginRequestDto loginRequestDto){

        return ResponseEntity.ok(authService.login(loginRequestDto));
    }
}
