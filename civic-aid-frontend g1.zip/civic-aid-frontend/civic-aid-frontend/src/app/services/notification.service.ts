import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { NotificationResponse } from '../models/notification.model';
import { Page } from '../models/program.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class NotificationService {
  private apiUrl = `${environment.apiGatewayUrl}/notifications`;

  constructor(private http: HttpClient) {}

  getNotifications(recipientId: number, page: number = 0, size: number = 20): Observable<Page<NotificationResponse>> {
    const params = new HttpParams().set('page', page).set('size', size);
    return this.http.get<Page<NotificationResponse>>(`${this.apiUrl}/recipient/${recipientId}`, { params });
  }

  getUnreadNotifications(recipientId: number, page: number = 0, size: number = 20): Observable<Page<NotificationResponse>> {
    const params = new HttpParams().set('page', page).set('size', size);
    return this.http.get<Page<NotificationResponse>>(`${this.apiUrl}/recipient/${recipientId}/unread`, { params });
  }

  getUnreadCount(recipientId: number): Observable<number> {
    return this.http.get<number>(`${this.apiUrl}/recipient/${recipientId}/unread/count`);
  }

  markAsRead(id: number): Observable<string> {
    return this.http.patch(`${this.apiUrl}/${id}/read`, null, { responseType: 'text' });
  }

  markAllAsRead(recipientId: number): Observable<number> {
    return this.http.patch<number>(`${this.apiUrl}/recipient/${recipientId}/read-all`, null);
  }

  deleteNotification(id: number): Observable<string> {
    return this.http.delete(`${this.apiUrl}/${id}`, { responseType: 'text' });
  }
}
