package com.cognizant.Report.repository;

import com.cognizant.Report.entity.ProgramReport;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProgramRepo
        extends JpaRepository<ProgramReport, Long> {

    long countByStatus(ProgramReport.ProgramStatus status);
}
