export type Role = 'CITIZEN' | 'WELFARE_OFFICER' | 'PROGRAM_MANAGER' | 'ADMINISTRATOR' | 'COMPLIANCE_OFFICER' | 'GOVERNMENT_AUDITOR';
export type UserStatus = 'ACTIVE' | 'INACTIVE' | 'SUSPENDED';

export interface RegisterRequest {
  name: string;
  email: string;
  password: string;
  phone?: string;
  role: Role;
}

export interface RegisterResponse {
  userId: number;
  name: string;
  email: string;
  phone: string;
  role: Role;
  status: UserStatus;
  createdAt: string;
  updatedAt: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  email: string;
  role: string;
}

export interface UserDto {
  userId: number;
  name: string;
  email: string;
  phone: string;
  role: Role;
  status: UserStatus;
  createdAt: string;
  updatedAt: string;
}
