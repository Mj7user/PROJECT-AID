package com.cognizant.ProgramAndScheme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class ProgramAndSchemeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgramAndSchemeApplication.class, args);
	}

}
