package com.cognizant.civicaid.controller;

import com.cognizant.civicaid.dto.request.AuditRequest;
import com.cognizant.civicaid.dto.response.AuditResponse;
import com.cognizant.civicaid.entity.Audit;
import com.cognizant.civicaid.entity.User;
import com.cognizant.civicaid.exception.ResourceNotFoundException;
import com.cognizant.civicaid.repository.UserRepository;
import com.cognizant.civicaid.service.AuditService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/audits")
@RequiredArgsConstructor
@Slf4j
public class AuditController {

    private final AuditService auditService;
    private final UserRepository userRepository;

    @PostMapping
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<AuditResponse> createAudit(
            @AuthenticationPrincipal UserDetails userDetails,
            @Valid @RequestBody AuditRequest request) {

        log.info("Create Audit request received by user: {}", userDetails.getUsername());

        User officer = userRepository.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> {
                    log.error("User not found for email: {}", userDetails.getUsername());
                    return new ResourceNotFoundException("User not found");
                });

        AuditResponse response = auditService.createAudit(officer.getUserId(), request);

        log.info("Audit created successfully with ID: {}", response.getAuditId());
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','ADMINISTRATOR','GOVERNMENT_AUDITOR')")
    public ResponseEntity<AuditResponse> getAuditById(@PathVariable Long id) {

        log.debug("Fetching audit with ID: {}", id);
        AuditResponse response = auditService.getAuditById(id);
        log.info("Audit fetched successfully for ID: {}", id);

        return ResponseEntity.ok(response);
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','ADMINISTRATOR','GOVERNMENT_AUDITOR')")
    public ResponseEntity<Page<AuditResponse>> getAllAudits(
            @PageableDefault(size = 20) Pageable pageable,
            @RequestParam(required = false) Audit.AuditStatus status) {

        log.debug("Fetching audits | status: {} | page: {}", status, pageable.getPageNumber());

        Page<AuditResponse> result = status != null
                ? auditService.getAuditsByStatus(status, pageable)
                : auditService.getAllAudits(pageable);

        log.info("Fetched {} audits", result.getTotalElements());
        return ResponseEntity.ok(result);
    }

    @GetMapping("/my")
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<Page<AuditResponse>> getMyAudits(
            @AuthenticationPrincipal UserDetails userDetails,
            @PageableDefault(size = 20) Pageable pageable) {

        log.info("Fetching audits for logged-in officer: {}", userDetails.getUsername());

        User officer = userRepository.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> {
                    log.error("User not found for email: {}", userDetails.getUsername());
                    return new ResourceNotFoundException("User not found");
                });

        Page<AuditResponse> audits =
                auditService.getAuditsByOfficer(officer.getUserId(), pageable);

        log.info("Officer {} has {} audits",
                officer.getUserId(), audits.getTotalElements());

        return ResponseEntity.ok(audits);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<AuditResponse> updateAudit(
            @PathVariable Long id,
            @Valid @RequestBody AuditRequest request) {

        log.info("Update Audit request received for ID: {}", id);

        AuditResponse response = auditService.updateAudit(id, request);

        log.info("Audit updated successfully for ID: {}", id);
        return ResponseEntity.ok(response);
    }
}