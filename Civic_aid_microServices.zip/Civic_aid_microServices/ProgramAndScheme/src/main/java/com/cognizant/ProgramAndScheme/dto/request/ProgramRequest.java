package com.cognizant.ProgramAndScheme.dto.request;

import com.cognizant.ProgramAndScheme.entity.Program;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProgramRequest {
    private String title;
    private String description;
    private LocalDate startDate;
    private LocalDate endDate;
    private BigDecimal budget;
    private Program.ProgramStatus status;
}