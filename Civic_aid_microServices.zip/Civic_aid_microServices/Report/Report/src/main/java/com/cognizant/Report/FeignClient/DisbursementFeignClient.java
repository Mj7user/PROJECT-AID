package com.cognizant.Report.FeignClient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Map;

@FeignClient(name = "disbursement-service", path = "/disbursements")
public interface DisbursementFeignClient {

    @GetMapping("/stats")
    Map<String, Object> getDisbursementStats();
}