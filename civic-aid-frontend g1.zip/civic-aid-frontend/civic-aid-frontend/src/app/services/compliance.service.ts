import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuditRequest, AuditResponse, AuditStatus, ComplianceRecordRequest, ComplianceRecordResponse, ComplianceResult, EntityType } from '../models/compliance.model';
import { Page } from '../models/program.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ComplianceService {
  private complianceUrl = `${environment.apiGatewayUrl}/compliance`;
  private auditUrl = `${environment.apiGatewayUrl}/audits`;

  constructor(private http: HttpClient) {}

  // Compliance
  createComplianceRecord(reviewerId: number, request: ComplianceRecordRequest): Observable<ComplianceRecordResponse> {
    const params = new HttpParams().set('reviewerId', reviewerId);
    return this.http.post<ComplianceRecordResponse>(this.complianceUrl, request, { params });
  }

  getComplianceById(id: number): Observable<ComplianceRecordResponse> {
    return this.http.get<ComplianceRecordResponse>(`${this.complianceUrl}/${id}`);
  }

  getComplianceByEntity(entityId: number, entityType: EntityType): Observable<ComplianceRecordResponse[]> {
    const params = new HttpParams().set('entityId', entityId).set('entityType', entityType);
    return this.http.get<ComplianceRecordResponse[]>(`${this.complianceUrl}/entity`, { params });
  }

  getAllCompliance(page: number = 0, size: number = 20, result?: ComplianceResult): Observable<Page<ComplianceRecordResponse>> {
    let params = new HttpParams().set('page', page).set('size', size);
    if (result) params = params.set('result', result);
    return this.http.get<Page<ComplianceRecordResponse>>(this.complianceUrl, { params });
  }

  // Audits
  createAudit(officerId: number, request: AuditRequest): Observable<AuditResponse> {
    const params = new HttpParams().set('officerId', officerId);
    return this.http.post<AuditResponse>(this.auditUrl, request, { params });
  }

  getAuditById(id: number): Observable<AuditResponse> {
    return this.http.get<AuditResponse>(`${this.auditUrl}/${id}`);
  }

  getAllAudits(page: number = 0, size: number = 20, status?: AuditStatus, officerId?: number): Observable<Page<AuditResponse>> {
    let params = new HttpParams().set('page', page).set('size', size);
    if (status) params = params.set('status', status);
    if (officerId) params = params.set('officerId', officerId);
    return this.http.get<Page<AuditResponse>>(this.auditUrl, { params });
  }
}
