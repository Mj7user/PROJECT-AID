import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RegisterResponse, UserDto } from '../models/user.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class UserService {
  private apiUrl = `${environment.apiGatewayUrl}/users`;

  constructor(private http: HttpClient) {}

  getUserByEmail(email: string): Observable<UserDto> {
    return this.http.get<UserDto>(`${this.apiUrl}/email/${email}`);
  }

  getAllUsers(): Observable<RegisterResponse[]> {
    return this.http.get<RegisterResponse[]>(`${this.apiUrl}/getallusers`);
  }

  getUserById(id: number): Observable<RegisterResponse> {
    return this.http.get<RegisterResponse>(`${this.apiUrl}/${id}`);
  }

  deleteUser(id: number): Observable<string> {
    return this.http.delete(`${this.apiUrl}/${id}`, { responseType: 'text' });
  }
}
