package com.cognizant.ComplianceAndAuditService.Repository;

import com.cognizant.ComplianceAndAuditService.Entity.ComplianceRecord;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ComplianceRecordRepository extends JpaRepository<ComplianceRecord, Long> {

    List<ComplianceRecord> findByEntityIdAndEntityType(
            Long entityId,
            ComplianceRecord.EntityType entityType
    );

    Page<ComplianceRecord> findByResult(
            ComplianceRecord.ComplianceResult result,
            Pageable pageable
    );
}
