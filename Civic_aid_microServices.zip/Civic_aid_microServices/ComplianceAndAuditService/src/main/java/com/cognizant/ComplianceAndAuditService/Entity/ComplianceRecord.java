package com.cognizant.ComplianceAndAuditService.Entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "compliance_records")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ComplianceRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long complianceId;

    @Column(nullable = false)
    private Long entityId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EntityType entityType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ComplianceResult result;

    @Column(columnDefinition = "TEXT")
    private String notes;

    @Column(nullable = false)
    private Long reviewedById;

    @CreationTimestamp
    private LocalDateTime createdAt;

    public enum EntityType {
        APPLICATION,
        PROGRAM,
        CITIZEN,
        DISBURSEMENT,
        PAYMENT
    }

    public enum ComplianceResult {
        COMPLIANT,
        NON_COMPLIANT,
        UNDER_REVIEW,
        PENDING
    }
}
