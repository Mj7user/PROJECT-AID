export type NotificationCategory = 'APPLICATION' | 'DISBURSEMENT' | 'COMPLIANCE' | 'SYSTEM' | 'GENERAL';
export type NotificationStatus = 'UNREAD' | 'READ';

export interface NotificationResponse {
  notificationId: number;
  recipientId: number;
  entityId: number;
  message: string;
  category: NotificationCategory;
  status: NotificationStatus;
  createdAt: string;
  readAt: string;
}
