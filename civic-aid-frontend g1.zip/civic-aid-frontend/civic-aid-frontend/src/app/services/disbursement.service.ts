import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DisbursementRequest, DisbursementResponse, DisbursementStatus } from '../models/disbursement.model';
import { Page } from '../models/program.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class DisbursementService {
  private apiUrl = `${environment.apiGatewayUrl}/disbursements`;

  constructor(private http: HttpClient) {}

  create(request: DisbursementRequest): Observable<DisbursementResponse> {
    return this.http.post<DisbursementResponse>(this.apiUrl, request);
  }

  getById(id: number): Observable<DisbursementResponse> {
    return this.http.get<DisbursementResponse>(`${this.apiUrl}/${id}`);
  }

  getAll(page: number = 0, size: number = 20, status?: DisbursementStatus): Observable<Page<DisbursementResponse>> {
    let params = new HttpParams().set('page', page).set('size', size);
    if (status) params = params.set('status', status);
    return this.http.get<Page<DisbursementResponse>>(this.apiUrl, { params });
  }

  getByApplication(applicationId: number): Observable<DisbursementResponse[]> {
    return this.http.get<DisbursementResponse[]>(`${this.apiUrl}/application/${applicationId}`);
  }

  updateStatus(id: number, status: DisbursementStatus): Observable<DisbursementResponse> {
    const params = new HttpParams().set('status', status);
    return this.http.patch<DisbursementResponse>(`${this.apiUrl}/${id}/status`, null, { params });
  }
}
