package com.cognizant.authentication.enums;

public enum Status {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}
