package com.cognizant.programservice.dao;

import com.cognizant.programservice.entity.Scheme;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SchemeRepository extends JpaRepository<Scheme, Long> {
    List<Scheme> findByProgram_ProgramId(Long programId);
    
    @Query("SELECT s FROM Scheme s WHERE s.program.programId = :programId AND s.status = 'ACTIVE'")
    List<Scheme> findActiveSchemesByProgramId(@Param("programId") Long programId);
}
