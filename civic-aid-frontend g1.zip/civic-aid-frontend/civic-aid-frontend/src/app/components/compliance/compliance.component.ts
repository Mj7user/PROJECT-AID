import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ComplianceService } from '../../services/compliance.service';
import { ComplianceRecordResponse, ComplianceRecordRequest, ComplianceResult, EntityType } from '../../models/compliance.model';

@Component({
  selector: 'app-compliance',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './compliance.component.html',
  styleUrls: ['./compliance.component.scss']
})
export class ComplianceComponent implements OnInit {
  records: ComplianceRecordResponse[] = [];
  loading = true; showModal = false; currentPage = 0; totalPages = 0;
  filterResult: ComplianceResult | '' = '';
  formData: ComplianceRecordRequest = { entityId: 0, entityType: 'APPLICATION', result: 'PENDING' };
  reviewerId = 0;
  results: ComplianceResult[] = ['COMPLIANT', 'NON_COMPLIANT', 'UNDER_REVIEW', 'PENDING'];
  entityTypes: EntityType[] = ['APPLICATION', 'PROGRAM', 'CITIZEN', 'DISBURSEMENT', 'PAYMENT'];
  error = ''; success = '';

  constructor(private service: ComplianceService) {}
  ngOnInit() { this.load(); }

  load() {
    this.loading = true;
    this.service.getAllCompliance(this.currentPage, 20, this.filterResult || undefined).subscribe({
      next: (page) => { this.records = page.content; this.totalPages = page.totalPages; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  openCreate() { this.formData = { entityId: 0, entityType: 'APPLICATION', result: 'PENDING' }; this.reviewerId = 0; this.error = ''; this.showModal = true; }

  create() {
    if (!this.formData.entityId || !this.reviewerId) { this.error = 'Entity ID and Reviewer ID are required'; return; }
    this.service.createComplianceRecord(this.reviewerId, this.formData).subscribe({
      next: () => { this.showModal = false; this.success = 'Compliance record created'; this.load(); setTimeout(() => this.success = '', 3000); },
      error: (err) => { this.error = err.error?.message || 'Failed'; }
    });
  }

  onFilterChange() { this.currentPage = 0; this.load(); }

  getResultClass(r: string): string {
    const m: Record<string, string> = { 'COMPLIANT': 'badge-success', 'NON_COMPLIANT': 'badge-danger', 'UNDER_REVIEW': 'badge-warning', 'PENDING': 'badge-info' };
    return m[r] || 'badge-muted';
  }

  formatDate(d: string): string { return d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'; }
  prevPage() { if (this.currentPage > 0) { this.currentPage--; this.load(); } }
  nextPage() { if (this.currentPage < this.totalPages - 1) { this.currentPage++; this.load(); } }
}
