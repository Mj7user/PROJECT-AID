package com.cognizant.Report.FeignClient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Map;

@FeignClient(name = "application-service", path = "/applications")
public interface ApplicationFeignClient {

    @GetMapping("/stats")
    Map<String, Object> getApplicationStats();
}