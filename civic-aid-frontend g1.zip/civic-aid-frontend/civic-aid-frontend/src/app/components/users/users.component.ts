import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserService } from '../../services/user.service';
import { RegisterResponse } from '../../models/user.model';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  users: RegisterResponse[] = [];
  loading = true;
  success = '';

  constructor(private userService: UserService) {}
  ngOnInit() { this.loadUsers(); }

  loadUsers() {
    this.loading = true;
    this.userService.getAllUsers().subscribe({
      next: (data) => { this.users = data; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  deleteUser(id: number) {
    if (confirm('Are you sure you want to delete this user?')) {
      this.userService.deleteUser(id).subscribe({
        next: () => { this.success = 'User deleted'; this.loadUsers(); setTimeout(() => this.success = '', 3000); }
      });
    }
  }

  getRoleClass(role: string): string {
    const m: Record<string, string> = { 'CITIZEN': 'badge-info', 'WELFARE_OFFICER': 'badge-primary', 'PROGRAM_MANAGER': 'badge-success', 'ADMINISTRATOR': 'badge-danger', 'COMPLIANCE_OFFICER': 'badge-warning', 'GOVERNMENT_AUDITOR': 'badge-muted' };
    return m[role] || 'badge-muted';
  }

  getStatusClass(s: string): string {
    return s === 'ACTIVE' ? 'badge-success' : s === 'INACTIVE' ? 'badge-muted' : 'badge-danger';
  }

  formatDate(d: string): string { return d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'; }
}
