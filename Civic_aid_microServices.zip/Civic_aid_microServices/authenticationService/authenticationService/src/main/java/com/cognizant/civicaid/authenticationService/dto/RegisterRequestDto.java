package com.cognizant.civicaid.authenticationService.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import com.cognizant.civicaid.authenticationService.enums.Role;
import lombok.Data;

@Data
public class RegisterRequestDto {

        @NotBlank
        private String name;
        @NotBlank @Email
        private String email;
        @NotBlank @Size(min = 6)
        private String password;
        private String phone;
        private Role role;
}
