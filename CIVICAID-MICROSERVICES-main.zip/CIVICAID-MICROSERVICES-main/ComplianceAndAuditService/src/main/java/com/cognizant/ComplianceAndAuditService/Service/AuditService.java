package com.cognizant.ComplianceAndAuditService.Service;

import com.cognizant.ComplianceAndAuditService.Request.AuditRequest;
import com.cognizant.ComplianceAndAuditService.Response.AuditResponse;
import com.cognizant.ComplianceAndAuditService.Entity.Audit;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface AuditService {

    AuditResponse createAudit(Long officerId, AuditRequest request);

    AuditResponse getById(Long auditId);

    Page<AuditResponse> getAll(Pageable pageable);

    Page<AuditResponse> getByOfficer(Long officerId, Pageable pageable);

    Page<AuditResponse> getByStatus(
            Audit.AuditStatus status,
            Pageable pageable
    );
}