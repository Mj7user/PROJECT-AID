package com.cognizant.civicaid.controller;

import com.cognizant.civicaid.dto.request.PaymentRequest;
import com.cognizant.civicaid.dto.response.PaymentResponse;
import com.cognizant.civicaid.entity.Payment;
import com.cognizant.civicaid.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/payments")
@RequiredArgsConstructor
@Slf4j
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<PaymentResponse> initiatePayment(
            @Valid @RequestBody PaymentRequest request) {

        log.info("Initiate Payment request received");

        PaymentResponse response =
                paymentService.initiatePayment(request);

        log.info("Payment initiated successfully with ID: {}",
                response.getPaymentId());

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<PaymentResponse> getPaymentById(@PathVariable Long id) {

        log.debug("Fetching payment with ID: {}", id);

        PaymentResponse response =
                paymentService.getPaymentById(id);

        log.info("Payment fetched successfully for ID: {}", id);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR')")
    public ResponseEntity<Page<PaymentResponse>> getAllPayments(
            @PageableDefault(size = 20) Pageable pageable) {

        log.debug("Fetching all payments | page: {} | size: {}",
                pageable.getPageNumber(), pageable.getPageSize());

        Page<PaymentResponse> page =
                paymentService.getAllPayments(pageable);

        log.info("Fetched {} payments", page.getTotalElements());
        return ResponseEntity.ok(page);
    }

    @GetMapping("/disbursement/{disbursementId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<PaymentResponse>> getPaymentsByDisbursement(
            @PathVariable Long disbursementId) {

        log.debug("Fetching payments for disbursement ID: {}", disbursementId);

        List<PaymentResponse> responses =
                paymentService.getPaymentsByDisbursement(disbursementId);

        log.info("Fetched {} payments for disbursement ID: {}",
                responses.size(), disbursementId);

        return ResponseEntity.ok(responses);
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<PaymentResponse> updatePaymentStatus(
            @PathVariable Long id,
            @RequestParam Payment.PaymentStatus status) {

        log.info("Update Payment Status request | ID: {} | New Status: {}", id, status);

        PaymentResponse response =
                paymentService.updatePaymentStatus(id, status);

        log.info("Payment status updated successfully | ID: {}", id);
        return ResponseEntity.ok(response);
    }
}