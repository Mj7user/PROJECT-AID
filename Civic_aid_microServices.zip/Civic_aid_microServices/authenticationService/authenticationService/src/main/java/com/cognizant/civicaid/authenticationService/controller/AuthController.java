package com.cognizant.civicaid.authenticationService.controller;

import com.cognizant.civicaid.authenticationService.dto.LoginRequestDto;
import com.cognizant.civicaid.authenticationService.dto.LoginResponseDto;
import com.cognizant.civicaid.authenticationService.dto.RegisterRequestDto;
import com.cognizant.civicaid.authenticationService.dto.RegisterResponseDto;
import com.cognizant.civicaid.authenticationService.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<RegisterResponseDto>registerUser(
            @Valid @RequestBody RegisterRequestDto registerRequestDto){

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(authService.createUsers(registerRequestDto));
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponseDto>login(
            @Valid @RequestBody LoginRequestDto loginRequestDto){

        return ResponseEntity.ok(authService.login(loginRequestDto));
    }
}
