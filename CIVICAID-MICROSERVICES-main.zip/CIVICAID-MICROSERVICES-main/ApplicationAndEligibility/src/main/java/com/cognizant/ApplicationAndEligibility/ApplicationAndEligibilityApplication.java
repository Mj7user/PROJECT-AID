package com.cognizant.ApplicationAndEligibility;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationAndEligibilityApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationAndEligibilityApplication.class, args);
	}

}
