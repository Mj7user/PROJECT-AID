package com.cognizant.applicationservice.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "welfare_applications")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class WelfareApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long applicationId;

    @Column(nullable = false)
    private Long citizenId;

    @Column(nullable = false)
    private Long programId;

    @Builder.Default
    private LocalDate submittedDate = LocalDate.now();

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private ApplicationStatus status = ApplicationStatus.PENDING;

    @CreationTimestamp
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    public enum ApplicationStatus { PENDING, UNDER_REVIEW, APPROVED, REJECTED, DISBURSED }
}
