package com.cognizant.ApplicationAndEligibility.controller;

import com.cognizant.ApplicationAndEligibility.entity.WelfareApplication;
import com.cognizant.ApplicationAndEligibility.request.WelfareApplicationRequest;
import com.cognizant.ApplicationAndEligibility.response.WelfareApplicationResponse;
import com.cognizant.ApplicationAndEligibility.service.WelfareApplicationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/applications")
@RequiredArgsConstructor
public class WelfareApplicationController {

    private final WelfareApplicationService applicationService;

    /* =========================
       Submit Application
       ========================= */

    @PostMapping
    public ResponseEntity<WelfareApplicationResponse> submitApplication(
            @Valid @RequestBody WelfareApplicationRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(applicationService.submitApplication(request));
    }

    /* =========================
       Get Applications by Citizen
       ========================= */
    @GetMapping("/citizen/{citizenId}")
    public ResponseEntity<Page<WelfareApplicationResponse>> getApplicationsByCitizen(
            @PathVariable Long citizenId,
            @PageableDefault(size = 20) Pageable pageable
    ) {
        return ResponseEntity.ok(
                applicationService.getApplicationsByCitizen(citizenId, pageable)
        );
    }

    /* =========================
       Get Application by ID
       ========================= */
    @GetMapping("/{id}")
    public ResponseEntity<WelfareApplicationResponse> getApplicationById(
            @PathVariable Long id
    ) {
        return ResponseEntity.ok(
                applicationService.getApplicationById(id)
        );
    }

    /* =========================
       Get All Applications (filters optional)
       ========================= */
    @GetMapping
    public ResponseEntity<Page<WelfareApplicationResponse>> getAllApplications(
            @PageableDefault(size = 20) Pageable pageable,
            @RequestParam(required = false) WelfareApplication.ApplicationStatus status,
            @RequestParam(required = false) Long programId
    ) {
        if (status != null) {
            return ResponseEntity.ok(
                    applicationService.getApplicationsByStatus(status, pageable)
            );
        }

        if (programId != null) {
            return ResponseEntity.ok(
                    applicationService.getApplicationsByProgram(programId, pageable)
            );
        }

        return ResponseEntity.ok(
                applicationService.getAllApplications(pageable)
        );
    }

    /* =========================
       Update Application Status
       ========================= */
    @PatchMapping("/{id}/status")
    public ResponseEntity<WelfareApplicationResponse> updateApplicationStatus(
            @PathVariable Long id,
            @RequestParam WelfareApplication.ApplicationStatus status,
            @RequestParam(required = false) String remarks
    ) {
        return ResponseEntity.ok(
                applicationService.updateApplicationStatus(id, status, remarks)
        );
    }

    /* =========================
       Withdraw Application
       ========================= */
    @PatchMapping("/{id}/withdraw")
    public ResponseEntity<String> withdrawApplication(
            @PathVariable Long id
    ) {
        applicationService.withdrawApplication(id);
        return ResponseEntity.ok("Application withdrawn");
    }
}
