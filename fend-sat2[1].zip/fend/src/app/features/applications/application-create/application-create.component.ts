import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ApplicationService } from '../../../core/services/application.service';
import { NotificationService } from '../../../core/services/notification.service';
import { ProgramService } from '../../../core/services/program.service';
import { AuthService } from '../../../core/services/auth.service';
import { ProgramResponse, SchemeResponse } from '../../../core/models/program.model';
import { Role } from '../../../core/models/role.enum';

@Component({
  selector: 'app-application-create',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './application-create.component.html',
  styleUrl: './application-create.component.css'
})
export class ApplicationCreateComponent implements OnInit, OnDestroy {
  private fb = inject(FormBuilder);
  private applicationService = inject(ApplicationService);
  private programService = inject(ProgramService);
  private notificationService = inject(NotificationService);
  public authService = inject(AuthService); // Public so template can use
  private router = inject(Router);

  programs: ProgramResponse[] = [];
  schemes: SchemeResponse[] = [];
  saving = false;
  successMsg = '';
  errorMsg = '';
  private programSub?: Subscription;

  get isCitizen(): boolean {
    return this.authService.hasRole(Role.CITIZEN);
  }

  form: FormGroup = this.fb.group({
    citizenId: [this.authService.getCitizenId(), Validators.required],
    programId: [null, Validators.required],
    schemeId: [null] // Only for UI dropdown, not submitted
  });

  ngOnInit(): void {
    if (this.isCitizen) {
      this.form.get('citizenId')?.disable(); // Prevent edits
    }

    this.programService.getAllPrograms().subscribe({
      next: programs => this.programs = programs.filter(p => p.status === 'ACTIVE'),
      error: () => {}
    });

    // Listen to program selection to fetch schemes
    this.programSub = this.form.get('programId')?.valueChanges.subscribe(programId => {
      this.form.get('schemeId')?.setValue(null);
      if (programId) {
        this.programService.getSchemesByProgram(programId).subscribe({
          next: schemes => this.schemes = schemes,
          error: () => this.schemes = []
        });
      } else {
        this.schemes = [];
      }
    });
  }

  ngOnDestroy(): void {
    this.programSub?.unsubscribe();
  }

  isInvalid(field: string): boolean {
    const ctrl = this.form.get(field);
    return !!(ctrl && ctrl.invalid && ctrl.touched);
  }

  onSubmit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving = true;
    this.successMsg = '';
    this.errorMsg = '';

    const formData = { ...this.form.getRawValue() }; // getRawValue includes disabled fields
    delete formData.schemeId; // Don't submit schemeId

    this.applicationService.createApplication(formData).subscribe({
      next: resp => {
        this.saving = false;
        this.router.navigate(['/applications']);
      },
      error: err => {
        this.errorMsg = err.error?.message || err.error || 'Failed to submit application';
        this.saving = false;
      }
    });
  }

  goBack(): void { this.router.navigate(['/applications']); }
}

