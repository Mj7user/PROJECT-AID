package com.cognizant.ApplicationAndEligibility.repository;

import com.cognizant.ApplicationAndEligibility.entity.WelfareApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;
import java.util.List;

public interface WelfareApplicationRepository
        extends JpaRepository<WelfareApplication, Long> {

    Page<WelfareApplication> findByCitizenId(
            Long citizenId,
            Pageable pageable
    );

    Page<WelfareApplication> findByProgramId(
            Long programId,
            Pageable pageable
    );

    Page<WelfareApplication> findByStatus(
            WelfareApplication.ApplicationStatus status,
            Pageable pageable
    );

    boolean existsByCitizenIdAndProgramId(
            Long citizenId,
            Long programId
    );

    @Query("""
        SELECT COUNT(a)
        FROM WelfareApplication a
        WHERE a.status = :status
    """)
    long countByStatus(
            WelfareApplication.ApplicationStatus status
    );

    @Query("""
        SELECT COUNT(a)
        FROM WelfareApplication a
        WHERE a.submittedDate BETWEEN :from AND :to
    """)
    long countBySubmittedDateBetween(
            LocalDateTime from,
            LocalDateTime to
    );

    @Query("""
        SELECT a
        FROM WelfareApplication a
        WHERE a.citizenId = :citizenId
        AND a.status = :status
    """)
    List<WelfareApplication> findByCitizenAndStatus(
            Long citizenId,
            WelfareApplication.ApplicationStatus status
    );
}