package com.cognizant.ProgramAndScheme.repository;

import com.cognizant.ProgramAndScheme.entity.Scheme;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SchemeRepository extends JpaRepository<Scheme, Long> {
    List<Scheme> findByProgram_ProgramId(Long programId);
}
