package com.cognizant.RegistrationAndManagement.request;

import com.cognizant.RegistrationAndManagement.entity.CitizenDocument;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CitizenDocumentRequest {

        @NotNull
        private Long citizenId;

        @NotNull
        private CitizenDocument.DocType docType;

        @NotBlank
        private String fileUri;
}
