package com.cognizant.RegistrationAndManagement.controller;

import com.cognizant.RegistrationAndManagement.entity.Citizen;
import com.cognizant.RegistrationAndManagement.request.CitizenRequest;
import com.cognizant.RegistrationAndManagement.response.CitizenResponse;
import com.cognizant.RegistrationAndManagement.service.CitizenService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/citizens")
@RequiredArgsConstructor
public class CitizenController {

    private final CitizenService citizenService;

    @PostMapping
    public ResponseEntity<CitizenResponse> registerCitizen(
            @Valid @RequestBody CitizenRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(citizenService.registerCitizen(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CitizenResponse> getCitizenById(
            @PathVariable Long id
    ) {
        return ResponseEntity.ok(citizenService.getCitizenById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CitizenResponse> updateCitizen(
            @PathVariable Long id,
            @Valid @RequestBody CitizenRequest request
    ) {
        return ResponseEntity.ok(
                citizenService.updateCitizen(id, request)
        );
    }

    @GetMapping
    public ResponseEntity<Page<CitizenResponse>> getAllCitizens(
            @PageableDefault(size = 10) Pageable pageable,
            @RequestParam(required = false) String search
    ) {
        Page<CitizenResponse> result =
                search != null
                        ? citizenService.searchCitizens(search, pageable)
                        : citizenService.getAllCitizens(pageable);

        return ResponseEntity.ok(result);
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<String> updateCitizenStatus(
            @PathVariable Long id,
            @RequestParam Citizen.CitizenStatus status
    ) {
        citizenService.updateCitizenStatus(id, status);
        return ResponseEntity.ok("Citizen status updated successfully");
    }
}