package com.cognizant.civicaid.authenticationService.dto;

import com.cognizant.civicaid.authenticationService.enums.Role;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {

    private String email;
    private Role role;
    private String password;
}
