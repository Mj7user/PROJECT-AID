package com.cognizant.ApplicationAndEligibility.FeignClient;

import com.cognizant.ApplicationAndEligibility.response.ProgramResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "program-service", path = "/programs")
public interface ProgramFeignClient {

    @GetMapping("/{id}")
    ProgramResponse getProgramById(@PathVariable Long id);

    @GetMapping("/{id}/status")
    String getProgramStatus(@PathVariable Long id);
}