package com.cognizant.ComplianceAndAuditService.Repository;

import com.cognizant.ComplianceAndAuditService.Entity.Audit;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuditRepository extends JpaRepository<Audit, Long> {

    Page<Audit> findByOfficerId(Long officerId, Pageable pageable);

    Page<Audit> findByStatus(Audit.AuditStatus status, Pageable pageable);
}