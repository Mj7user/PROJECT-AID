import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Page, ProgramRequest, ProgramResponse, SchemeRequest, SchemeResponse, SchemeStatus } from '../models/program.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ProgramService {
  private programUrl = `${environment.apiGatewayUrl}/programs`;
  private schemeUrl = `${environment.apiGatewayUrl}/schemes`;

  constructor(private http: HttpClient) {}

  // Programs
  createProgram(request: ProgramRequest): Observable<ProgramResponse> {
    return this.http.post<ProgramResponse>(this.programUrl, request);
  }

  getProgramById(id: number): Observable<ProgramResponse> {
    return this.http.get<ProgramResponse>(`${this.programUrl}/${id}`);
  }

  getAllPrograms(page: number = 0, size: number = 20): Observable<Page<ProgramResponse>> {
    const params = new HttpParams().set('page', page).set('size', size);
    return this.http.get<Page<ProgramResponse>>(this.programUrl, { params });
  }

  // Schemes
  createScheme(request: SchemeRequest): Observable<SchemeResponse> {
    return this.http.post<SchemeResponse>(this.schemeUrl, request);
  }

  getSchemeById(id: number): Observable<SchemeResponse> {
    return this.http.get<SchemeResponse>(`${this.schemeUrl}/${id}`);
  }

  getAllSchemes(page: number = 0, size: number = 20): Observable<Page<SchemeResponse>> {
    const params = new HttpParams().set('page', page).set('size', size);
    return this.http.get<Page<SchemeResponse>>(this.schemeUrl, { params });
  }

  getSchemesByProgram(programId: number): Observable<SchemeResponse[]> {
    return this.http.get<SchemeResponse[]>(`${this.schemeUrl}/program/${programId}`);
  }

  updateScheme(id: number, request: SchemeRequest): Observable<SchemeResponse> {
    return this.http.put<SchemeResponse>(`${this.schemeUrl}/${id}`, request);
  }

  updateSchemeStatus(id: number, status: SchemeStatus): Observable<string> {
    const params = new HttpParams().set('status', status);
    return this.http.patch(`${this.schemeUrl}/${id}/status`, null, { params, responseType: 'text' });
  }

  deleteScheme(id: number): Observable<string> {
    return this.http.delete(`${this.schemeUrl}/${id}`, { responseType: 'text' });
  }
}
