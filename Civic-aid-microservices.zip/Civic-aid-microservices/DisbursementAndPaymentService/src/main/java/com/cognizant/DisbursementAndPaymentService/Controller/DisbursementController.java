package com.cognizant.DisbursementAndPaymentService.Controller;


import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/disbursements")
@RequiredArgsConstructor
@Slf4j
public class DisbursementController {

        private final DisbursementService disbursementService;


        @PostMapping
        public ResponseEntity<DisbursementResponse> createDisbursement(
                @Valid @RequestBody DisbursementRequest request) {

            log.info("Create Disbursement request received");

            DisbursementResponse response =
                    disbursementService.createDisbursement(request);

            log.info("Disbursement created successfully with ID: {}", response.getDisbursementId());
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        }


        @GetMapping("/{id}")
        public ResponseEntity<DisbursementResponse> getDisbursementById(
                @PathVariable Long id) {

            log.debug("Fetching disbursement with ID: {}", id);

            DisbursementResponse response =
                    disbursementService.getDisbursementById(id);

            log.info("Disbursement fetched successfully for ID: {}", id);
            return ResponseEntity.ok(response);
        }


        @GetMapping
        public ResponseEntity<Page<DisbursementResponse>> getAllDisbursements(
                @PageableDefault(size = 20) Pageable pageable,
                @RequestParam(required = false)
                Disbursement.DisbursementStatus status) {

            log.debug("Fetching disbursements | status: {} | page: {} | size: {}",
                    status, pageable.getPageNumber(), pageable.getPageSize());

            Page<DisbursementResponse> result = status != null
                    ? disbursementService.getDisbursementsByStatus(status, pageable)
                    : disbursementService.getAllDisbursements(pageable);

            log.info("Fetched {} disbursements", result.getTotalElements());
            return ResponseEntity.ok(result);
        }


        @GetMapping("/application/{applicationId}")
        public ResponseEntity<List<DisbursementResponse>> getDisbursementsByApplication(
                @PathVariable Long applicationId) {

            log.debug("Fetching disbursements for application ID: {}", applicationId);

            List<DisbursementResponse> responses =
                    disbursementService.getDisbursementsByApplication(applicationId);

            log.info("Fetched {} disbursements for application ID: {}",
                    responses.size(), applicationId);

            return ResponseEntity.ok(responses);
        }


        @PatchMapping("/{id}/status")
        public ResponseEntity<DisbursementResponse> updateDisbursementStatus(
                @PathVariable Long id,
                @RequestParam Disbursement.DisbursementStatus status) {

            log.info("Update Disbursement Status request | ID: {} | New Status: {}", id, status);

            DisbursementResponse response =
                    disbursementService.updateDisbursementStatus(id, status);

            log.info("Disbursement status updated successfully | ID: {}", id);
            return ResponseEntity.ok(response);
        }
    }

}
