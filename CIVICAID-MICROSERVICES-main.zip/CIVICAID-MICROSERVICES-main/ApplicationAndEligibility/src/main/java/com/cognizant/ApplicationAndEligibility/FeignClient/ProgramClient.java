package com.cognizant.ApplicationAndEligibility.FeignClient;


@FeignClient(name = "program-service")
public interface ProgramClient {

    @GetMapping("/programs/{programId}")
    ProgramDTO getProgramById(@PathVariable Long programId);

    @GetMapping("/programs/{programId}/status")
    String getProgramStatus(@PathVariable Long programId);
}
