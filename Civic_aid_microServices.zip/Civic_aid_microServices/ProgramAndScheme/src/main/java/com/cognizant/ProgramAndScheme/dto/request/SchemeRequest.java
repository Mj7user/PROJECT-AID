package com.cognizant.ProgramAndScheme.dto.request;

import com.cognizant.ProgramAndScheme.entity.Scheme;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SchemeRequest {
    private Long programId;
    private String title;
    private String description;
    private String eligibilityCriteria;
    private Scheme.SchemeStatus status;
}
