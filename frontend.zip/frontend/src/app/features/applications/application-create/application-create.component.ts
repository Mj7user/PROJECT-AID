import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApplicationService } from '../../../core/services/application.service';
import { ProgramService } from '../../../core/services/program.service';
import { AuthService } from '../../../core/services/auth.service';
import { ProgramResponse } from '../../../core/models/program.model';

@Component({
  selector: 'app-application-create',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './application-create.component.html',
  styleUrl: './application-create.component.css'
})
export class ApplicationCreateComponent implements OnInit {
  private fb = inject(FormBuilder);
  private applicationService = inject(ApplicationService);
  private programService = inject(ProgramService);
  private authService = inject(AuthService);
  private router = inject(Router);

  programs: ProgramResponse[] = [];
  saving = false;
  successMsg = '';
  errorMsg = '';

  form: FormGroup = this.fb.group({
    citizenId: [this.authService.getCitizenId(), Validators.required],
    programId: [null, Validators.required]
  });

  ngOnInit(): void {
    this.programService.getAllPrograms().subscribe({
      next: programs => this.programs = programs.filter(p => p.status === 'ACTIVE'),
      error: () => {}
    });
  }

  isInvalid(field: string): boolean {
    const ctrl = this.form.get(field);
    return !!(ctrl && ctrl.invalid && ctrl.touched);
  }

  onSubmit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.saving = true;
    this.successMsg = '';
    this.errorMsg = '';

    this.applicationService.createApplication(this.form.value).subscribe({
      next: resp => {
        this.successMsg = `Application #${resp.applicationId} submitted! Status: ${resp.status}`;
        this.saving = false;
      },
      error: err => {
        this.errorMsg = err.error?.message || err.error || 'Failed to submit application';
        this.saving = false;
      }
    });
  }

  goBack(): void { this.router.navigate(['/applications']); }
}
