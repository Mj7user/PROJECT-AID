import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { CitizenService } from '../../../core/services/citizen.service';
import { CitizenResponse, DocumentResponse } from '../../../core/models/citizen.model';
import { Role } from '../../../core/models/role.enum';
import { LoaderComponent } from '../../../shared/components/loader/loader.component';

@Component({
  selector: 'app-citizen-profile',
  standalone: true,
  imports: [CommonModule, FormsModule, LoaderComponent],
  templateUrl: './citizen-profile.component.html',
  styleUrl: './citizen-profile.component.css'
})
export class CitizenProfileComponent implements OnInit {
  private authService = inject(AuthService);
  private citizenService = inject(CitizenService);
  private router = inject(Router);

  loading = true;
  citizenProfile: CitizenResponse | null = null;
  documents: DocumentResponse[] = [];
  allCitizens: CitizenResponse[] = [];
  showUpload = false;
  newDoc = { docType: 'ID_PROOF', fileUri: '' };

  get isCitizen(): boolean { return this.authService.hasRole(Role.CITIZEN); }
  get canEdit(): boolean { return this.authService.hasRole(Role.CITIZEN, Role.WELFARE_OFFICER, Role.ADMINISTRATOR); }
  get canEditOther(): boolean { return this.authService.hasRole(Role.WELFARE_OFFICER, Role.ADMINISTRATOR); }
  get canVerifyDocs(): boolean { return this.authService.hasRole(Role.WELFARE_OFFICER, Role.ADMINISTRATOR); }

  ngOnInit(): void {
    if (this.isCitizen) this.loadOwnProfile();
    else this.loadAllCitizens();
  }

  private loadOwnProfile(): void {
    const userId = this.authService.getUserId();
    if (!userId) { this.loading = false; return; }
    this.citizenService.getCitizenByUserId(userId).subscribe({
      next: citizen => {
        this.citizenProfile = citizen;
        this.authService.setCitizenId(citizen.citizenId);
        this.loadDocuments(citizen.citizenId);
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }

  private loadDocuments(citizenId: number): void {
    this.citizenService.getDocumentsByCitizen(citizenId).subscribe({
      next: docs => this.documents = docs, error: () => {}
    });
  }

  private loadAllCitizens(): void {
    this.citizenService.getAllCitizens().subscribe({
      next: citizens => { this.allCitizens = citizens; this.loading = false; },
      error: () => this.loading = false
    });
  }

  editProfile(): void {
    if (this.citizenProfile) this.router.navigate(['/citizens/edit', this.citizenProfile.citizenId]);
  }

  editCitizen(id: number): void { this.router.navigate(['/citizens/edit', id]); }

  viewCitizenDocs(citizenId: number): void {
    this.citizenService.getDocumentsByCitizen(citizenId).subscribe({
      next: docs => alert(
        `Docs for Citizen #${citizenId}:\n${docs.length ? docs.map(d => `${d.docType}: ${d.verificationStatus}`).join('\n') : 'No documents'}`
      )
    });
  }

  verifyDocument(docId: number, status: string): void {
    this.citizenService.verifyDocument(docId, status).subscribe({
      next: updated => {
        const idx = this.documents.findIndex(d => d.documentId === docId);
        if (idx >= 0) this.documents[idx] = updated;
      },
      error: err => alert(err.error || 'Verification failed')
    });
  }

  uploadDocument(): void {
    if (!this.citizenProfile || !this.newDoc.fileUri) return;
    this.citizenService.uploadDocument({
      citizenId: this.citizenProfile.citizenId,
      docType: this.newDoc.docType as any,
      fileUri: this.newDoc.fileUri
    }).subscribe({
      next: () => {
        this.showUpload = false;
        this.newDoc = { docType: 'ID_PROOF', fileUri: '' };
        this.loadDocuments(this.citizenProfile!.citizenId);
      },
      error: err => alert(err.error || 'Upload failed')
    });
  }

  getVerificationClass(status: string): string {
    const map: Record<string, string> = { VERIFIED: 'badge-success', REJECTED: 'badge-danger', PENDING: 'badge-warning' };
    return map[status] || 'badge-neutral';
  }
}
