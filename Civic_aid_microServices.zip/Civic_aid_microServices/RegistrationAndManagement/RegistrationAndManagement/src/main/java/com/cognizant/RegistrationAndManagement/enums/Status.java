package com.cognizant.RegistrationAndManagement.enums;

public enum Status {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}
