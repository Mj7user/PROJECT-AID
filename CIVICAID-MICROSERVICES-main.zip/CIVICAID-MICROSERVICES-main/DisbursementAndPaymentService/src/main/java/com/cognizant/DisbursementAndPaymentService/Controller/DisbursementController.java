package com.cognizant.DisbursementAndPaymentService.Controller;

import com.cognizant.DisbursementAndPaymentService.Entity.Disbursement;
import com.cognizant.DisbursementAndPaymentService.Request.DisbursementRequest;
import com.cognizant.DisbursementAndPaymentService.Response.DisbursementResponse;
import com.cognizant.DisbursementAndPaymentService.Service.DisbursementService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/disbursements")
@RequiredArgsConstructor
public class DisbursementController {

    private final DisbursementService service;

    @PostMapping
    public ResponseEntity<DisbursementResponse> create(
            @Valid @RequestBody DisbursementRequest request) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(service.createDisbursement(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<DisbursementResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getById(id));
    }

    @GetMapping
    public ResponseEntity<Page<DisbursementResponse>> getAll(
            @PageableDefault(size = 20) Pageable pageable,
            @RequestParam(required = false)
            Disbursement.DisbursementStatus status) {

        Page<DisbursementResponse> page =
                (status != null)
                        ? service.getByStatus(status, pageable)
                        : service.getAll(pageable);

        return ResponseEntity.ok(page);
    }

    @GetMapping("/application/{applicationId}")
    public ResponseEntity<List<DisbursementResponse>> getByApplication(
            @PathVariable Long applicationId) {

        return ResponseEntity.ok(service.getByApplication(applicationId));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<DisbursementResponse> updateStatus(
            @PathVariable Long id,
            @RequestParam Disbursement.DisbursementStatus status) {

        return ResponseEntity.ok(service.updateStatus(id, status));
    }
}