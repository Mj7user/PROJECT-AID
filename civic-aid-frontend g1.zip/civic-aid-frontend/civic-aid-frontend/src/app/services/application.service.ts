import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { WelfareApplicationRequest, WelfareApplicationResponse, ApplicationStatus, EligibilityCheckRequest, EligibilityCheckResponse } from '../models/application.model';
import { Page } from '../models/program.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ApplicationService {
  private appUrl = `${environment.apiGatewayUrl}/applications`;
  private eligUrl = `${environment.apiGatewayUrl}/eligibility-checks`;

  constructor(private http: HttpClient) {}

  // Applications
  submitApplication(request: WelfareApplicationRequest): Observable<WelfareApplicationResponse> {
    return this.http.post<WelfareApplicationResponse>(this.appUrl, request);
  }

  getApplicationsByCitizen(citizenId: number, page: number = 0, size: number = 20): Observable<Page<WelfareApplicationResponse>> {
    const params = new HttpParams().set('page', page).set('size', size);
    return this.http.get<Page<WelfareApplicationResponse>>(`${this.appUrl}/citizen/${citizenId}`, { params });
  }

  getApplicationById(id: number): Observable<WelfareApplicationResponse> {
    return this.http.get<WelfareApplicationResponse>(`${this.appUrl}/${id}`);
  }

  getAllApplications(page: number = 0, size: number = 20, status?: ApplicationStatus, programId?: number): Observable<Page<WelfareApplicationResponse>> {
    let params = new HttpParams().set('page', page).set('size', size);
    if (status) params = params.set('status', status);
    if (programId) params = params.set('programId', programId);
    return this.http.get<Page<WelfareApplicationResponse>>(this.appUrl, { params });
  }

  updateApplicationStatus(id: number, status: ApplicationStatus, remarks?: string): Observable<WelfareApplicationResponse> {
    let params = new HttpParams().set('status', status);
    if (remarks) params = params.set('remarks', remarks);
    return this.http.patch<WelfareApplicationResponse>(`${this.appUrl}/${id}/status`, null, { params });
  }

  withdrawApplication(id: number): Observable<string> {
    return this.http.patch(`${this.appUrl}/${id}/withdraw`, null, { responseType: 'text' });
  }

  // Eligibility Checks
  performCheck(request: EligibilityCheckRequest): Observable<EligibilityCheckResponse> {
    return this.http.post<EligibilityCheckResponse>(this.eligUrl, request);
  }

  getChecksByApplication(applicationId: number): Observable<EligibilityCheckResponse[]> {
    return this.http.get<EligibilityCheckResponse[]>(`${this.eligUrl}/application/${applicationId}`);
  }

  getLatestCheck(applicationId: number): Observable<EligibilityCheckResponse> {
    return this.http.get<EligibilityCheckResponse>(`${this.eligUrl}/application/${applicationId}/latest`);
  }
}
