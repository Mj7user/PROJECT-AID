package com.cognizant.DisbursementAndPaymentService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DisbursementAndPaymentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
