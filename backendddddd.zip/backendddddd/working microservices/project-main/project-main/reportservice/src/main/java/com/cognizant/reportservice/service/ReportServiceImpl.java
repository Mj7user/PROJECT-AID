package com.cognizant.reportservice.service;
import com.cognizant.reportservice.dao.ReportRepository; import com.cognizant.reportservice.dto.*; import com.cognizant.reportservice.entity.Report;
import com.cognizant.reportservice.exception.ResourceNotFoundException; import lombok.RequiredArgsConstructor; import org.springframework.stereotype.Service; import java.util.List; import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class ReportServiceImpl implements ReportService {
    private final ReportRepository reportRepository;
    @Override
    public ReportResponseDto generateReport(ReportRequestDto dto) {
        Report r = Report.builder().scope(dto.getScope()).metrics(dto.getMetrics()).build();
        return toDto(reportRepository.save(r));
    }
    @Override
    public ReportResponseDto getReportById(Long id) {
        return toDto(reportRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Report not found: " + id)));
    }
    @Override
    public List<ReportResponseDto> getAllReports() {
        return reportRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }
    @Override
    public List<ReportResponseDto> getReportsByScope(String scope) {
        return reportRepository.findByScope(Report.ReportScope.valueOf(scope.toUpperCase())).stream().map(this::toDto).collect(Collectors.toList());
    }
    private ReportResponseDto toDto(Report r) {
        return ReportResponseDto.builder().reportId(r.getReportId()).scope(r.getScope()).metrics(r.getMetrics()).generatedDate(r.getGeneratedDate()).createdAt(r.getCreatedAt()).build();
    }
}
