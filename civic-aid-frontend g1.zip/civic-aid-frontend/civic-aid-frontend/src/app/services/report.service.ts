import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ReportService {
  private apiUrl = `${environment.apiGatewayUrl}/reports`;

  constructor(private http: HttpClient) {}

  getDashboardStats(): Observable<Record<string, any>> {
    return this.http.get<Record<string, any>>(`${this.apiUrl}/dashboard`);
  }

  getApplicationStats(): Observable<Record<string, any>> {
    return this.http.get<Record<string, any>>(`${this.apiUrl}/applications`);
  }

  getDisbursementStats(): Observable<Record<string, any>> {
    return this.http.get<Record<string, any>>(`${this.apiUrl}/disbursements`);
  }

  getComplianceStats(): Observable<Record<string, any>> {
    return this.http.get<Record<string, any>>(`${this.apiUrl}/compliance`);
  }

  getProgramStats(programId: number): Observable<Record<string, any>> {
    return this.http.get<Record<string, any>>(`${this.apiUrl}/programs/${programId}`);
  }
}
