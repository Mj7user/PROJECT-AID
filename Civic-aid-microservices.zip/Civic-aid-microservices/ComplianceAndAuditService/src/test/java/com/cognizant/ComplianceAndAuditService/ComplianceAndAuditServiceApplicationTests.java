package com.cognizant.ComplianceAndAuditService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComplianceAndAuditServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
