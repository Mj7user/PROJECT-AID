package com.cognizant.civicaid.authenticationService.enums;

public enum Status {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}
