package com.cognizant.civicaid.service;

import com.cognizant.civicaid.dto.request.AuthRequest;
import com.cognizant.civicaid.dto.response.LoginResponse;
import com.cognizant.civicaid.dto.response.RegisterResponse;

public interface AuthService {
    LoginResponse login(AuthRequest.Login request);
    RegisterResponse register(AuthRequest.Register request);
    void logout(String token);
}
