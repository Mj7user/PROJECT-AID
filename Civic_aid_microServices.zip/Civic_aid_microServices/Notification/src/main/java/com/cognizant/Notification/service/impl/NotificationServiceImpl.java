package com.cognizant.Notification.service.impl;

import com.cognizant.Notification.dto.response.NotificationResponse;
import com.cognizant.Notification.entity.Notification;
import com.cognizant.Notification.exception.ResourceNotFoundException;
import com.cognizant.Notification.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository repository;

    @Override
    @Async
    @Transactional
    public void sendNotification(
            Long recipientId,
            Long entityId,
            String message,
            Notification.NotificationCategory category
    ) {
        Notification notification = Notification.builder()
                .recipientId(recipientId)
                .entityId(entityId)
                .message(message)
                .category(category)
                .build();

        repository.save(notification);
        log.info("Notification sent to recipient {}", recipientId);
    }

    @Override
    public Page<NotificationResponse> getNotifications(
            Long recipientId,
            Pageable pageable
    ) {
        return repository
                .findByRecipientId(recipientId, pageable)
                .map(this::map);
    }

    @Override
    public Page<NotificationResponse> getUnreadNotifications(
            Long recipientId,
            Pageable pageable
    ) {
        return repository
                .findByRecipientIdAndStatus(
                        recipientId,
                        Notification.NotificationStatus.UNREAD,
                        pageable
                )
                .map(this::map);
    }

    @Override
    public long getUnreadCount(Long recipientId) {
        return repository.countByRecipientIdAndStatus(
                recipientId,
                Notification.NotificationStatus.UNREAD
        );
    }

    @Override
    @Transactional
    public void markAsRead(Long notificationId) {
        Notification n = repository.findById(notificationId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Notification", notificationId));

        n.setStatus(Notification.NotificationStatus.READ);
        n.setReadAt(LocalDateTime.now());
        repository.save(n);
    }

    @Override
    @Transactional
    public int markAllAsRead(Long recipientId) {
        return repository.markAllAsRead(recipientId);
    }

    @Override
    @Transactional
    public void deleteNotification(Long notificationId) {
        if (!repository.existsById(notificationId)) {
            throw new ResourceNotFoundException("Notification", notificationId);
        }
        repository.deleteById(notificationId);
    }

    private NotificationResponse map(Notification n) {
        return NotificationResponse.builder()
                .notificationId(n.getNotificationId())
                .recipientId(n.getRecipientId())
                .entityId(n.getEntityId())
                .message(n.getMessage())
                .category(n.getCategory())
                .status(n.getStatus())
                .createdAt(n.getCreatedAt())
                .readAt(n.getReadAt())
                .build();
    }
}