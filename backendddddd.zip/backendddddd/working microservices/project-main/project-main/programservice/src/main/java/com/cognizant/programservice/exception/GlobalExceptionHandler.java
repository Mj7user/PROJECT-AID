package com.cognizant.programservice.exception;
import org.springframework.http.*; import org.springframework.web.bind.annotation.*; import java.time.LocalDateTime; import java.util.Map;
@RestControllerAdvice public class GlobalExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class) public ResponseEntity<Map<String,Object>> h1(ResourceNotFoundException e) { return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("timestamp",LocalDateTime.now().toString(),"error","Not Found","message",e.getMessage())); }
    @ExceptionHandler(BusinessException.class) public ResponseEntity<Map<String,Object>> h2(BusinessException e) { return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("timestamp",LocalDateTime.now().toString(),"error","Bad Request","message",e.getMessage())); }
    @ExceptionHandler(Exception.class) public ResponseEntity<Map<String,Object>> h3(Exception e) { return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("timestamp",LocalDateTime.now().toString(),"error","Internal Server Error","message",e.getMessage())); }
}
