package com.cognizant.RegistrationAndManagement.repository;

import com.cognizant.RegistrationAndManagement.entity.Citizen;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface CitizenRepository extends JpaRepository<Citizen, Long> {

    Optional<Citizen> findByUserId(Long userId);

    boolean existsByUserId(Long userId);

    Page<Citizen> findByStatus(Citizen.CitizenStatus status, Pageable pageable);

    @Query("""
        SELECT c FROM Citizen c
        WHERE LOWER(c.name) LIKE LOWER(CONCAT('%', :name, '%'))
    """)
    Page<Citizen> searchByName(String name, Pageable pageable);

    long countByStatus(Citizen.CitizenStatus status);
}