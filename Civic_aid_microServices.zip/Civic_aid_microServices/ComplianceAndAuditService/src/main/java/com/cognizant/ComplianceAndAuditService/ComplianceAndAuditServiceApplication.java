package com.cognizant.ComplianceAndAuditService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class ComplianceAndAuditServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComplianceAndAuditServiceApplication.class, args);
	}

}
