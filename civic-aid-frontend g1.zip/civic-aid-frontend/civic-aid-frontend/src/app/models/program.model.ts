export type ProgramStatus = 'DRAFT' | 'ACTIVE' | 'INACTIVE' | 'PAUSED' | 'COMPLETED' | 'CANCELLED';
export type SchemeStatus = 'ACTIVE' | 'INACTIVE' | 'ARCHIVED';

export interface ProgramRequest {
  title: string;
  description: string;
  startDate: string;
  endDate?: string;
  budget: number;
  status?: ProgramStatus;
}

export interface ProgramResponse {
  programId: number;
  title: string;
  description: string;
  startDate: string;
  endDate: string;
  budget: number;
  status: ProgramStatus;
  createdAt: string;
  updatedAt: string;
}

export interface SchemeRequest {
  programId: number;
  title: string;
  description: string;
  eligibilityCriteria: string;
  status?: SchemeStatus;
}

export interface SchemeResponse {
  schemeId: number;
  programId: number;
  programTitle: string;
  title: string;
  description: string;
  eligibilityCriteria: string;
  status: SchemeStatus;
  createdAt: string;
  updatedAt: string;
}

export interface Page<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
  first: boolean;
  last: boolean;
  empty: boolean;
}
