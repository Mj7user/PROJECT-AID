package com.cognizant.DisbursementAndPaymentService.Repository;
import com.cognizant.DisbursementAndPaymentService.Entity.DisbursementEntity;
import org.hibernate.query.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.awt.print.Pageable;
import java.math.BigDecimal;
import java.util.List;

public interface DisbursementRepository extends JpaRepository<DisbursementEntity, Long>
    {

        List<DisbursementEntity> findByApplicationId(Long applicationId);

        Page<DisbursementEntity> findByStatus(
                DisbursementEntity.DisbursementStatus status,
                Pageable pageable
        );

        @Query("""
        SELECT SUM(d.amount)
        FROM DisbursementEntity d
        WHERE d.status = 'COMPLETED'""")
        BigDecimal sumCompletedDisbursements();

        @Query("""
        SELECT SUM(d.amount)
        FROM DisbursementEntity d
        WHERE d.programId = :programId
          AND d.status = 'COMPLETED'
        """)
        BigDecimal sumDisbursedAmountByProgram(Long programId);

        long countByStatus(DisbursementEntity.DisbursementStatus status);
    }
}
