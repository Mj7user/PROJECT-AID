package com.cognizant.ApplicationAndEligibility.service.impl;

import com.cognizant.ApplicationAndEligibility.entity.EligibilityCheck;
import com.cognizant.ApplicationAndEligibility.entity.WelfareApplication;
import com.cognizant.ApplicationAndEligibility.repository.EligibilityCheckRepository;
import com.cognizant.ApplicationAndEligibility.repository.WelfareApplicationRepository;
import com.cognizant.ApplicationAndEligibility.request.EligibilityCheckRequest;
import com.cognizant.ApplicationAndEligibility.response.EligibilityCheckResponse;
import com.cognizant.ApplicationAndEligibility.service.EligibilityCheckService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EligibilityCheckServiceImpl implements EligibilityCheckService {

    private final EligibilityCheckRepository checkRepository;
    private final WelfareApplicationRepository welfareApplicationRepository;

    // ✅ FIXED: signature matches interface
    @Override
    @Transactional
    public EligibilityCheckResponse performCheck(
            EligibilityCheckRequest request
    ) {
        WelfareApplication application = welfareApplicationRepository
                .findById(request.getApplicationId())
                .orElseThrow(() ->
                        new IllegalArgumentException("Application not found"));

        EligibilityCheck check = EligibilityCheck.builder()
                .application(application)
                .officerId(request.getOfficerId())
                .result(request.getResult())
                .notes(request.getNotes())
                .build();

        switch (request.getResult()) {
            case ELIGIBLE ->
                    application.setStatus(WelfareApplication.ApplicationStatus.ELIGIBLE);
            case INELIGIBLE ->
                    application.setStatus(WelfareApplication.ApplicationStatus.INELIGIBLE);
            default ->
                    application.setStatus(WelfareApplication.ApplicationStatus.UNDER_REVIEW);
        }

        welfareApplicationRepository.save(application);
        return map(checkRepository.save(check));
    }

    // ✅ FIXED: method name EXACTLY matches interface
    @Override
    public List<EligibilityCheckResponse> getChecksByApplication(
            Long applicationId
    ) {
        return checkRepository
                .findByApplication_ApplicationId(applicationId)
                .stream()
                .map(this::map)
                .toList();
    }

    @Override
    public EligibilityCheckResponse getLatestCheck(
            Long applicationId
    ) {
        return checkRepository
                .findTopByApplication_ApplicationIdOrderByDateDesc(applicationId)
                .map(this::map)
                .orElseThrow(() ->
                        new IllegalArgumentException("No eligibility checks found"));
    }

    // ✅ REQUIRED mapper (was already correct)
    private EligibilityCheckResponse map(EligibilityCheck e) {
        return EligibilityCheckResponse.builder()
                .checkId(e.getCheckId())
                .applicationId(e.getApplication().getApplicationId())
                .officerId(e.getOfficerId())
                .result(e.getResult())
                .date(e.getDate())
                .notes(e.getNotes())
                .build();
    }
}
