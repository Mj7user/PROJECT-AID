package com.cognizant.ApplicationAndEligibility.request;

import com.cognizant.ApplicationAndEligibility.entity.EligibilityCheck;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EligibilityCheckRequest {


    @NotNull
    private Long applicationId;

    @NotNull
    private Long officerId;

    @NotNull
    private EligibilityCheck.CheckResult result;

    private String notes;
}