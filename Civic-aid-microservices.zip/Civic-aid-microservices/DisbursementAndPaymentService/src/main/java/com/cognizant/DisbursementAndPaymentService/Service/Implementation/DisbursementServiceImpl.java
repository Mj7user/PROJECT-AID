package com.cognizant.civicaid.service.impl;

import com.cognizant.civicaid.dto.request.DisbursementRequest;
import com.cognizant.civicaid.dto.response.DisbursementResponse;
import com.cognizant.civicaid.entity.*;
import com.cognizant.civicaid.exception.BusinessException;
import com.cognizant.civicaid.exception.ResourceNotFoundException;
import com.cognizant.civicaid.repository.DisbursementRepository;
import com.cognizant.civicaid.repository.WelfareApplicationRepository;
import com.cognizant.civicaid.repository.UserRepository;
import com.cognizant.civicaid.service.AuditLogService;
import com.cognizant.civicaid.service.DisbursementService;
import com.cognizant.civicaid.service.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class DisbursementServiceImpl implements DisbursementService {

    private final DisbursementRepository disbursementRepository;
    private final WelfareApplicationRepository applicationRepository;
    private final NotificationService notificationService;
    private final AuditLogService auditLogService;
    private final UserRepository userRepository;

    private Long currentUserId() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByEmail(email)
                .map(User::getUserId)
                .orElse(null);
    }

    @Override
    @Transactional
    public DisbursementResponse createDisbursement(DisbursementRequest request) {

        log.info("Creating disbursement | applicationId={} | amount={}",
                request.getApplicationId(), request.getAmount());

        WelfareApplication application = applicationRepository
                .findById(request.getApplicationId())
                .orElseThrow(() -> {
                    log.error("Application not found | applicationId={}",
                            request.getApplicationId());
                    return new ResourceNotFoundException(
                            "Application", request.getApplicationId());
                });

        if (application.getStatus()
                != WelfareApplication.ApplicationStatus.APPROVED) {

            log.error("Invalid application state for disbursement | applicationId={} | status={}",
                    application.getApplicationId(), application.getStatus());

            throw new BusinessException(
                    "Disbursement can only be created for APPROVED applications");
        }

        Disbursement disbursement = Disbursement.builder()
                .application(application)
                .amount(request.getAmount())
                .remarks(request.getRemarks())
                .status(Disbursement.DisbursementStatus.PENDING)
                .build();

        disbursement = disbursementRepository.save(disbursement);

        application.setStatus(WelfareApplication.ApplicationStatus.DISBURSED);
        applicationRepository.save(application);

        log.info("Disbursement created successfully | disbursementId={}",
                disbursement.getDisbursementId());

        auditLogService.log(
                currentUserId(),
                "CREATE_DISBURSEMENT",
                "DISBURSEMENT",
                "Disbursement ID: " + disbursement.getDisbursementId()
                        + " of ₹" + request.getAmount()
                        + " created for application ID: "
                        + request.getApplicationId(),
                null
        );

        notificationService.sendNotification(
                application.getCitizen().getUser().getUserId(),
                disbursement.getDisbursementId(),
                "A disbursement of ₹" + request.getAmount()
                        + " has been initiated for your application.",
                Notification.NotificationCategory.DISBURSEMENT
        );

        log.info("Audit log and notification sent | disbursementId={}",
                disbursement.getDisbursementId());

        return mapToResponse(disbursement);
    }

    @Override
    public DisbursementResponse getDisbursementById(Long id) {

        log.debug("Fetching disbursement | disbursementId={}", id);

        Disbursement disbursement = disbursementRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Disbursement not found | disbursementId={}", id);
                    return new ResourceNotFoundException("Disbursement", id);
                });

        return mapToResponse(disbursement);
    }

    @Override
    public List<DisbursementResponse> getDisbursementsByApplication(Long applicationId) {

        log.debug("Fetching disbursements for application | applicationId={}", applicationId);

        List<DisbursementResponse> list =
                disbursementRepository
                        .findByApplication_ApplicationId(applicationId)
                        .stream()
                        .map(this::mapToResponse)
                        .toList();

        log.info("Fetched {} disbursements | applicationId={}",
                list.size(), applicationId);

        return list;
    }

    @Override
    public Page<DisbursementResponse> getDisbursementsByStatus(
            Disbursement.DisbursementStatus status, Pageable pageable) {

        log.debug("Fetching disbursements | status={}", status);

        Page<DisbursementResponse> page =
                disbursementRepository
                        .findByStatus(status, pageable)
                        .map(this::mapToResponse);

        log.info("Fetched {} disbursements | status={}",
                page.getTotalElements(), status);

        return page;
    }

    @Override
    public Page<DisbursementResponse> getAllDisbursements(Pageable pageable) {

        log.debug("Fetching all disbursements | page={} | size={}",
                pageable.getPageNumber(), pageable.getPageSize());

        Page<DisbursementResponse> page =
                disbursementRepository
                        .findAll(pageable)
                        .map(this::mapToResponse);

        log.info("Fetched {} disbursements", page.getTotalElements());
        return page;
    }

    @Override
    @Transactional
    public DisbursementResponse updateDisbursementStatus(
            Long id, Disbursement.DisbursementStatus status) {

        log.info("Updating disbursement status | disbursementId={} | newStatus={}",
                id, status);

        Disbursement disbursement = disbursementRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Disbursement not found for status update | disbursementId={}", id);
                    return new ResourceNotFoundException("Disbursement", id);
                });

        disbursement.setStatus(status);
        disbursement = disbursementRepository.save(disbursement);

        auditLogService.log(
                currentUserId(),
                "UPDATE_DISBURSEMENT_STATUS",
                "DISBURSEMENT",
                "Disbursement ID: " + id
                        + " status changed to: " + status.name(),
                null
        );

        notificationService.sendNotification(
                disbursement.getApplication().getCitizen().getUser().getUserId(),
                disbursement.getDisbursementId(),
                "Your disbursement status has been updated to: "
                        + status.name(),
                Notification.NotificationCategory.DISBURSEMENT
        );

        log.info("Disbursement status updated & notification sent | disbursementId={}", id);

        return mapToResponse(disbursement);
    }

    private DisbursementResponse mapToResponse(Disbursement d) {
        return DisbursementResponse.builder()
                .disbursementId(d.getDisbursementId())
                .applicationId(d.getApplication().getApplicationId())
                .citizenName(d.getApplication().getCitizen().getName())
                .programTitle(d.getApplication().getProgram().getTitle())
                .amount(d.getAmount())
                .date(d.getDate())
                .status(d.getStatus())
                .remarks(d.getRemarks())
                .updatedAt(d.getUpdatedAt())
                .build();
    }
}