package com.cognizant.Report.repository;

import com.cognizant.Report.entity.DisbursementReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;

public interface DisbursementRepo
        extends JpaRepository<DisbursementReport, Long> {

    long countByStatus(DisbursementReport.DisbursementStatus status);

    @Query("""
        SELECT COALESCE(SUM(d.amount), 0)
        FROM DisbursementReport d
        WHERE d.status = 'COMPLETED'
    """)
    BigDecimal sumCompletedAmounts();

    @Query("""
        SELECT COALESCE(SUM(d.amount), 0)
        FROM DisbursementReport d
        WHERE d.programId = :programId
          AND d.status = 'COMPLETED'
    """)
    BigDecimal sumCompletedAmountsByProgram(Long programId);
}
