package com.cognizant.ComplianceAndAuditService.Request;

import com.cognizant.ComplianceAndAuditService.Entity.Audit;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AuditRequest {

    @NotBlank
    private String scope;

    private String findings;

    @NotNull
    private Audit.AuditStatus status;
}