package com.cognizant.ApplicationAndEligibility.FeignClient;

@FeignClient(name = "citizen-service")
public interface CitizenClient {

    @GetMapping("/citizens/{citizenId}")
    CitizenDTO getCitizenById(@PathVariable Long citizenId);
}
