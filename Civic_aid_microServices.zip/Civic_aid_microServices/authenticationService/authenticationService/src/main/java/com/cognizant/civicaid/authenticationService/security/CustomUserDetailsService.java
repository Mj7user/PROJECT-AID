package com.cognizant.civicaid.authenticationService.security;

import com.cognizant.civicaid.authenticationService.dto.UserDto;
import com.cognizant.civicaid.authenticationService.externalService.UserServiceClient;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService{

    private final UserServiceClient userServiceClient;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        try {
            UserDto user = userServiceClient.findByEmail(email);

            if (user == null) {
                throw new UsernameNotFoundException("User not found with email: " + email);
            }

            GrantedAuthority authority = new SimpleGrantedAuthority("ROLE_" + user.getRole());

            return org.springframework.security.core.userdetails.User.builder()
                    .username(user.getEmail())
                    .password(user.getPassword())
                    .authorities(List.of(authority))
                    .build();
        } catch (Exception e) {
            throw new UsernameNotFoundException("Error communicating with User Service", e);
        }
    }
}
