package com.cognizant.reportservice.entity;
import jakarta.persistence.*; import lombok.*; import org.hibernate.annotations.*; import java.time.*;
@Entity @Table(name="reports") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Report {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long reportId;
    @Enumerated(EnumType.STRING) private ReportScope scope;
    @Column(columnDefinition="TEXT") private String metrics;
    @Builder.Default private LocalDate generatedDate = LocalDate.now();
    @CreationTimestamp private LocalDateTime createdAt;
    public enum ReportScope { CITIZEN, APPLICATION, PROGRAM, DISBURSEMENT, COMPLIANCE }
}
