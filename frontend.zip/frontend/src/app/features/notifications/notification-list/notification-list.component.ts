import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationService } from '../../../core/services/notification.service';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationResponse } from '../../../core/models/application.model';
import { LoaderComponent } from '../../../shared/components/loader/loader.component';

@Component({
  selector: 'app-notification-list',
  standalone: true,
  imports: [CommonModule, LoaderComponent],
  templateUrl: './notification-list.component.html',
  styleUrl: './notification-list.component.css'
})
export class NotificationListComponent implements OnInit {
  private notificationService = inject(NotificationService);
  private authService = inject(AuthService);

  notifications: NotificationResponse[] = [];
  loading = true;
  unreadCount = 0;

  ngOnInit(): void { this.loadNotifications(); }

  loadNotifications(): void {
    const userId = this.authService.getUserId();
    if (!userId) { this.loading = false; return; }
    this.notificationService.getNotificationsByUser(userId).subscribe({
      next: notifs => {
        this.notifications = notifs.sort((a, b) =>
          new Date(b.createdDate).getTime() - new Date(a.createdDate).getTime()
        );
        this.unreadCount = notifs.filter(n => n.status === 'UNREAD').length;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }

  markRead(id: number): void {
    this.notificationService.markAsRead(id).subscribe({
      next: updated => {
        const idx = this.notifications.findIndex(n => n.notificationId === id);
        if (idx >= 0) this.notifications[idx] = updated;
        this.unreadCount = this.notifications.filter(n => n.status === 'UNREAD').length;
      }
    });
  }

  getCategoryClass(category: string): string {
    const map: Record<string, string> = {
      APPLICATION: 'badge-primary', DISBURSEMENT: 'badge-success',
      PAYMENT: 'badge-success', COMPLIANCE: 'badge-warning',
      PROGRAM: 'badge-info', GENERAL: 'badge-neutral'
    };
    return map[category] || 'badge-neutral';
  }
}
