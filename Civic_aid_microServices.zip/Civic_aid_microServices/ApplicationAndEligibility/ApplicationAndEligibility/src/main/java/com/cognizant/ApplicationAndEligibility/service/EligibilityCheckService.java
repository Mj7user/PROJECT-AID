package com.cognizant.ApplicationAndEligibility.service;

import com.cognizant.ApplicationAndEligibility.request.EligibilityCheckRequest;
import com.cognizant.ApplicationAndEligibility.response.EligibilityCheckResponse;

import java.util.List;

public interface EligibilityCheckService {

    EligibilityCheckResponse performCheck(
            EligibilityCheckRequest request
    );

    List<EligibilityCheckResponse> getChecksByApplication(
            Long applicationId
    );

    EligibilityCheckResponse getLatestCheck(
            Long applicationId
    );
}