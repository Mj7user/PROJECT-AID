package com.cognizant.DisbursementAndPaymentService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DisbursementAndPaymentServiceApplication {

	public static void main(String[] args) {

		SpringApplication.run(DisbursementAndPaymentServiceApplication.class, args);
	}

}
