package com.cognizant.citizenservice.service;

import com.cognizant.citizenservice.dao.CitizenRepository;
import com.cognizant.citizenservice.dto.*;
import com.cognizant.citizenservice.entity.Citizen;
import com.cognizant.citizenservice.exception.BusinessException;
import com.cognizant.citizenservice.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CitizenServiceImpl implements CitizenService {

    private final CitizenRepository citizenRepository;

    @Override
    public CitizenResponseDto createCitizen(CitizenRequestDto dto) {
        Citizen citizen = Citizen.builder()
                .name(dto.getName()).dob(dto.getDob()).gender(dto.getGender())
                .address(dto.getAddress()).contactInfo(dto.getContactInfo())
                .userId(dto.getUserId()).build();
        return toDto(citizenRepository.save(citizen));
    }

    @Override
    public CitizenResponseDto getCitizenById(Long id) {
        return toDto(citizenRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen not found: " + id)));
    }

    @Override
    public CitizenResponseDto getCitizenByUserId(Long userId) {
        return toDto(citizenRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen not found for user: " + userId)));
    }

    @Override
    public List<CitizenResponseDto> getAllCitizens() {
        return citizenRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public CitizenResponseDto updateCitizen(Long id, CitizenRequestDto dto) {
        Citizen citizen = citizenRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen not found: " + id));
        citizen.setName(dto.getName());
        citizen.setDob(dto.getDob());
        citizen.setGender(dto.getGender());
        citizen.setAddress(dto.getAddress());
        citizen.setContactInfo(dto.getContactInfo());
        return toDto(citizenRepository.save(citizen));
    }

    @Override
    public void deleteCitizen(Long id) {
        citizenRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Citizen not found: " + id));
        citizenRepository.deleteById(id);
    }

    @Override
    public CitizenResponseDto registerCitizen(Long userId) {
        // Check if citizen already exists for this userId
        if (citizenRepository.findByUserId(userId).isPresent()) {
            throw new BusinessException("Citizen already exists for this user");
        }

        Citizen citizen = Citizen.builder()
                .userId(userId)
                .status(Citizen.CitizenStatus.ACTIVE)
                .build();

        return toDto(citizenRepository.save(citizen));
    }


    private CitizenResponseDto toDto(Citizen c) {
        return CitizenResponseDto.builder()
                .citizenId(c.getCitizenId()).name(c.getName()).dob(c.getDob())
                .gender(c.getGender()).address(c.getAddress()).contactInfo(c.getContactInfo())
                .status(c.getStatus()).userId(c.getUserId()).createdAt(c.getCreatedAt()).build();
    }
}
