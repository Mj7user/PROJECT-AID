package com.cognizant.Notification.repository;

import com.cognizant.Notification.entity.Notification;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {

    Page<Notification> findByRecipientId(Long recipientId, Pageable pageable);

    Page<Notification> findByRecipientIdAndStatus(
            Long recipientId,
            Notification.NotificationStatus status,
            Pageable pageable
    );

    long countByRecipientIdAndStatus(
            Long recipientId,
            Notification.NotificationStatus status
    );

    @Modifying
    @Query("""
        UPDATE Notification n 
        SET n.status = 'READ', n.readAt = CURRENT_TIMESTAMP
        WHERE n.recipientId = :recipientId AND n.status = 'UNREAD'
    """)
    int markAllAsRead(Long recipientId);
}