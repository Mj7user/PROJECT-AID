package com.cognizant.programservice.dto;

import com.cognizant.programservice.entity.Scheme;
import lombok.*;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SchemeRequestDto {
    private Long programId;
    private String title;
    private String description;
    @NonNull
    private BigDecimal budget;
    private String eligibilityCriteria;
    private Scheme.SchemeStatus status;
}
