import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DisbursementService } from '../../services/disbursement.service';
import { DisbursementResponse, DisbursementRequest, DisbursementStatus } from '../../models/disbursement.model';

@Component({
  selector: 'app-disbursements',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './disbursements.component.html',
  styleUrls: ['./disbursements.component.scss']
})
export class DisbursementsComponent implements OnInit {
  disbursements: DisbursementResponse[] = [];
  loading = true; showModal = false; currentPage = 0; totalPages = 0;
  filterStatus: DisbursementStatus | '' = '';
  formData: DisbursementRequest = { applicationId: 0, citizenId: 0, programId: 0, amount: 0 };
  statuses: DisbursementStatus[] = ['PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'CANCELLED'];
  error = ''; success = '';

  constructor(private service: DisbursementService) {}
  ngOnInit() { this.load(); }

  load() {
    this.loading = true;
    this.service.getAll(this.currentPage, 20, this.filterStatus || undefined).subscribe({
      next: (page) => { this.disbursements = page.content; this.totalPages = page.totalPages; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  openCreate() { this.formData = { applicationId: 0, citizenId: 0, programId: 0, amount: 0 }; this.error = ''; this.showModal = true; }

  create() {
    if (!this.formData.applicationId || !this.formData.amount) { this.error = 'Application ID and amount are required'; return; }
    this.service.create(this.formData).subscribe({
      next: () => { this.showModal = false; this.success = 'Disbursement created'; this.load(); setTimeout(() => this.success = '', 3000); },
      error: (err) => { this.error = err.error?.message || 'Failed to create'; }
    });
  }

  updateStatus(id: number, status: DisbursementStatus) {
    this.service.updateStatus(id, status).subscribe({ next: () => { this.success = 'Status updated'; this.load(); setTimeout(() => this.success = '', 3000); } });
  }

  onFilterChange() { this.currentPage = 0; this.load(); }

  getStatusClass(s: string): string {
    const m: Record<string, string> = { 'PENDING': 'badge-warning', 'PROCESSING': 'badge-info', 'COMPLETED': 'badge-success', 'FAILED': 'badge-danger', 'CANCELLED': 'badge-muted' };
    return m[s] || 'badge-muted';
  }

  formatCurrency(v: number): string { return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(v); }
  formatDate(d: string): string { return d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'; }
  prevPage() { if (this.currentPage > 0) { this.currentPage--; this.load(); } }
  nextPage() { if (this.currentPage < this.totalPages - 1) { this.currentPage++; this.load(); } }
}
