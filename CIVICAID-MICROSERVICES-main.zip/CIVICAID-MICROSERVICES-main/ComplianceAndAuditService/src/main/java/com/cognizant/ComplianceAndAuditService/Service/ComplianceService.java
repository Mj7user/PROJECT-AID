package com.cognizant.ComplianceAndAuditService.Service;

import com.cognizant.ComplianceAndAuditService.Request.ComplianceRecordRequest;
import com.cognizant.ComplianceAndAuditService.Response.ComplianceRecordResponse;
import com.cognizant.ComplianceAndAuditService.Entity.ComplianceRecord;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ComplianceService {

    ComplianceRecordResponse createRecord(Long reviewerId, ComplianceRecordRequest request);

    ComplianceRecordResponse getById(Long recordId);

    List<ComplianceRecordResponse> getByEntity(
            Long entityId,
            ComplianceRecord.EntityType entityType);

    Page<ComplianceRecordResponse> getByResult(
            ComplianceRecord.ComplianceResult result,
            Pageable pageable);

    Page<ComplianceRecordResponse> getAll(Pageable pageable);
}