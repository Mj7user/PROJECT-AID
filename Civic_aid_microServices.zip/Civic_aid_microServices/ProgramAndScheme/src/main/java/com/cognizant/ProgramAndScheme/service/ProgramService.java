package com.cognizant.ProgramAndScheme.service;

import com.cognizant.ProgramAndScheme.dto.request.ProgramRequest;
import com.cognizant.ProgramAndScheme.dto.response.ProgramResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ProgramService {

    ProgramResponse createProgram(ProgramRequest request);

    ProgramResponse getProgramById(Long id);

    Page<ProgramResponse> getAllPrograms(Pageable pageable);
}