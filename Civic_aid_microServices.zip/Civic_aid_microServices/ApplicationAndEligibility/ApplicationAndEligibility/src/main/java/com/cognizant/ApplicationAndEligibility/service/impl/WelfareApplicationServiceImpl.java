package com.cognizant.ApplicationAndEligibility.service.impl;

import com.cognizant.ApplicationAndEligibility.entity.WelfareApplication;
import com.cognizant.ApplicationAndEligibility.repository.WelfareApplicationRepository;
import com.cognizant.ApplicationAndEligibility.request.WelfareApplicationRequest;
import com.cognizant.ApplicationAndEligibility.response.WelfareApplicationResponse;
import com.cognizant.ApplicationAndEligibility.service.WelfareApplicationService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class WelfareApplicationServiceImpl implements WelfareApplicationService {

    private final WelfareApplicationRepository repository;


    @Override
    @Transactional
    public WelfareApplicationResponse submitApplication(
            WelfareApplicationRequest request
    ) {
        if (repository.existsByCitizenIdAndProgramId(
                request.getCitizenId(),
                request.getProgramId()
        )) {
            throw new IllegalStateException(
                    "Application already exists for this program"
            );
        }

        WelfareApplication app = WelfareApplication.builder()
                .citizenId(request.getCitizenId())
                .programId(request.getProgramId())
                .schemeId(request.getSchemeId())
                .remarks(request.getRemarks())
                .status(WelfareApplication.ApplicationStatus.SUBMITTED)
                .build();

        return map(repository.save(app));
    }

    @Override
    public WelfareApplicationResponse getApplicationById(Long id) {
        WelfareApplication app = repository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Application not found"));

        return map(app);
    }

    @Override
    public Page<WelfareApplicationResponse> getApplicationsByCitizen(
            Long citizenId,
            Pageable pageable
    ) {
        return repository.findByCitizenId(citizenId, pageable)
                .map(this::map);
    }

    @Override
    public Page<WelfareApplicationResponse> getApplicationsByProgram(
            Long programId,
            Pageable pageable
    ) {
        return repository.findByProgramId(programId, pageable)
                .map(this::map);
    }

    @Override
    public Page<WelfareApplicationResponse> getApplicationsByStatus(
            WelfareApplication.ApplicationStatus status,
            Pageable pageable
    ) {
        return repository.findByStatus(status, pageable)
                .map(this::map);
    }

    @Override
    public Page<WelfareApplicationResponse> getAllApplications(
            Pageable pageable
    ) {
        return repository.findAll(pageable)
                .map(this::map);
    }

    @Override
    @Transactional
    public WelfareApplicationResponse updateApplicationStatus(
            Long id,
            WelfareApplication.ApplicationStatus status,
            String remarks
    ) {
        WelfareApplication app = repository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Application not found"));

        app.setStatus(status);

        if (remarks != null) {
            app.setRemarks(remarks);
        }

        return map(repository.save(app));
    }

    @Override
    @Transactional
    public void withdrawApplication(Long id) {
        WelfareApplication app = repository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Application not found"));

        app.setStatus(WelfareApplication.ApplicationStatus.CLOSED);
        repository.save(app);
    }


    private WelfareApplicationResponse map(WelfareApplication a) {
        return WelfareApplicationResponse.builder()
                .applicationId(a.getApplicationId())
                .citizenId(a.getCitizenId())
                .programId(a.getProgramId())
                .schemeId(a.getSchemeId())
                .submittedDate(a.getSubmittedDate())
                .status(a.getStatus())
                .remarks(a.getRemarks())
                .updatedAt(a.getUpdatedAt())
                .build();
    }
}