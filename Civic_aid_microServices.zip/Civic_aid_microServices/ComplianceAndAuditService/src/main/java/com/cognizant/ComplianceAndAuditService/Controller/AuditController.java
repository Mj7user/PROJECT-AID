package com.cognizant.ComplianceAndAuditService.Controller;

import com.cognizant.ComplianceAndAuditService.Request.AuditRequest;
import com.cognizant.ComplianceAndAuditService.Response.AuditResponse;
import com.cognizant.ComplianceAndAuditService.Entity.Audit;
import com.cognizant.ComplianceAndAuditService.Service.AuditService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/audits")
@RequiredArgsConstructor
public class AuditController {

    private final AuditService auditService;

    @PostMapping
    public ResponseEntity<AuditResponse> createAudit(
            @RequestParam Long officerId,
            @Valid @RequestBody AuditRequest request) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(auditService.createAudit(officerId, request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<AuditResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(auditService.getById(id));
    }

    @GetMapping
    public ResponseEntity<Page<AuditResponse>> getAll(
            Pageable pageable,
            @RequestParam(required = false)
            Audit.AuditStatus status,
            @RequestParam(required = false)
            Long officerId) {

        if (officerId != null) {
            return ResponseEntity.ok(
                    auditService.getByOfficer(officerId, pageable));
        }

        if (status != null) {
            return ResponseEntity.ok(
                    auditService.getByStatus(status, pageable));
        }

        return ResponseEntity.ok(auditService.getAll(pageable));
    }
}