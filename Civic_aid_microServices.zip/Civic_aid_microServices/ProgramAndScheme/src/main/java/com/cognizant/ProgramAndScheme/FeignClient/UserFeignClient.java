package com.cognizant.ProgramAndScheme.FeignClient;

import com.cognizant.ProgramAndScheme.dto.response.RegisterResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "user-service", path = "/users")
public interface UserFeignClient {

    @GetMapping("/{id}")
    RegisterResponseDto getUserById(@PathVariable Long id);
}