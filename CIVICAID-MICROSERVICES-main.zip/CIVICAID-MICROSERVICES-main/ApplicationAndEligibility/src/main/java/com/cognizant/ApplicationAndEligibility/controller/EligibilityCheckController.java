package com.cognizant.ApplicationAndEligibility.controller;

import com.cognizant.ApplicationAndEligibility.request.EligibilityCheckRequest;
import com.cognizant.ApplicationAndEligibility.response.EligibilityCheckResponse;
import com.cognizant.ApplicationAndEligibility.service.EligibilityCheckService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/eligibility-checks")
@RequiredArgsConstructor
public class EligibilityCheckController {

    private final EligibilityCheckService eligibilityCheckService;

    @PostMapping
    public ResponseEntity<EligibilityCheckResponse> performCheck(
            @Valid @RequestBody EligibilityCheckRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(eligibilityCheckService.performCheck(request));
    }

    @GetMapping("/application/{applicationId}")
    public ResponseEntity<List<EligibilityCheckResponse>> getChecksByApplication(
            @PathVariable Long applicationId
    ) {
        return ResponseEntity.ok(
                eligibilityCheckService.getChecksByApplication(applicationId)
        );
    }

    @GetMapping("/application/{applicationId}/latest")
    public ResponseEntity<EligibilityCheckResponse> getLatestCheck(
            @PathVariable Long applicationId
    ) {
        return ResponseEntity.ok(
                eligibilityCheckService.getLatestCheck(applicationId)
        );
    }
}
