package com.civicaid.service;

public interface AuditLogService {
    void log(Long userId, String action, String resource, String details, String ipAddress);
}
