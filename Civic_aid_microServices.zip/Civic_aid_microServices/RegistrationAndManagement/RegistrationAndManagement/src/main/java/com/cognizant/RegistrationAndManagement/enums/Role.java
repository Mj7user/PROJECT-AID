package com.cognizant.RegistrationAndManagement.enums;

public enum Role {

    CITIZEN,
    WELFARE_OFFICER,
    PROGRAM_MANAGER,
    ADMINISTRATOR,
    COMPLIANCE_OFFICER,
    GOVERNMENT_AUDITOR
}
