package com.cognizant.civicaid.service.impl;

import com.cognizant.civicaid.dto.request.ComplianceRecordRequest;
import com.cognizant.civicaid.dto.response.ComplianceRecordResponse;
import com.cognizant.civicaid.entity.ComplianceRecord;
import com.cognizant.civicaid.entity.User;
import com.cognizant.civicaid.exception.ResourceNotFoundException;
import com.cognizant.civicaid.repository.ComplianceRecordRepository;
import com.cognizant.civicaid.repository.UserRepository;
import com.cognizant.civicaid.service.ComplianceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ComplianceServiceImpl implements ComplianceService {

    private final ComplianceRecordRepository complianceRecordRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public ComplianceRecordResponse createRecord(Long reviewerId, ComplianceRecordRequest request) {

        log.info("Creating Compliance Record | reviewerId={} | entityId={} | type={}",
                reviewerId, request.getEntityId(), request.getType());

        User reviewer = userRepository.findById(reviewerId)
                .orElseThrow(() -> {
                    log.error("Reviewer not found | reviewerId={}", reviewerId);
                    return new ResourceNotFoundException("User", reviewerId);
                });

        ComplianceRecord record = ComplianceRecord.builder()
                .entityId(request.getEntityId())
                .type(request.getType())
                .result(request.getResult())
                .notes(request.getNotes())
                .reviewedBy(reviewer)
                .build();

        ComplianceRecord savedRecord = complianceRecordRepository.save(record);

        log.info("Compliance Record created successfully | complianceId={} | result={}",
                savedRecord.getComplianceId(), savedRecord.getResult());

        return mapToResponse(savedRecord);
    }

    @Override
    public ComplianceRecordResponse getRecordById(Long id) {

        log.debug("Fetching Compliance Record | complianceId={}", id);

        ComplianceRecord record = complianceRecordRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Compliance Record not found | complianceId={}", id);
                    return new ResourceNotFoundException("Compliance Record", id);
                });

        return mapToResponse(record);
    }

    @Override
    public List<ComplianceRecordResponse> getRecordsByEntity(
            Long entityId, ComplianceRecord.EntityType type) {

        log.debug("Fetching Compliance Records | entityId={} | type={}", entityId, type);

        List<ComplianceRecordResponse> records =
                complianceRecordRepository.findByEntityIdAndType(entityId, type)
                        .stream()
                        .map(this::mapToResponse)
                        .toList();

        log.info("Fetched {} compliance records | entityId={} | type={}",
                records.size(), entityId, type);

        return records;
    }

    @Override
    public Page<ComplianceRecordResponse> getAllRecords(Pageable pageable) {

        log.debug("Fetching all Compliance Records | page={} | size={}",
                pageable.getPageNumber(), pageable.getPageSize());

        Page<ComplianceRecordResponse> page =
                complianceRecordRepository.findAll(pageable).map(this::mapToResponse);

        log.info("Fetched {} compliance records", page.getTotalElements());
        return page;
    }

    @Override
    public Page<ComplianceRecordResponse> getRecordsByResult(
            ComplianceRecord.ComplianceResult result, Pageable pageable) {

        log.debug("Fetching Compliance Records | result={}", result);

        Page<ComplianceRecordResponse> page =
                complianceRecordRepository.findByResult(result, pageable)
                        .map(this::mapToResponse);

        log.info("Fetched {} compliance records | result={}",
                page.getTotalElements(), result);

        return page;
    }

    @Override
    @Transactional
    public ComplianceRecordResponse updateRecord(Long id, ComplianceRecordRequest request) {

        log.info("Updating Compliance Record | complianceId={}", id);

        ComplianceRecord record = complianceRecordRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Compliance Record not found for update | complianceId={}", id);
                    return new ResourceNotFoundException("Compliance Record", id);
                });

        record.setResult(request.getResult());
        record.setNotes(request.getNotes());

        ComplianceRecord updatedRecord =
                complianceRecordRepository.save(record);

        log.info("Compliance Record updated successfully | complianceId={} | result={}",
                updatedRecord.getComplianceId(), updatedRecord.getResult());

        return mapToResponse(updatedRecord);
    }

    private ComplianceRecordResponse mapToResponse(ComplianceRecord cr) {
        return ComplianceRecordResponse.builder()
                .complianceId(cr.getComplianceId())
                .entityId(cr.getEntityId())
                .type(cr.getType())
                .result(cr.getResult())
                .date(cr.getDate())
                .notes(cr.getNotes())
                .reviewedById(cr.getReviewedBy() != null
                        ? cr.getReviewedBy().getUserId()
                        : null)
                .reviewedByName(cr.getReviewedBy() != null
                        ? cr.getReviewedBy().getName()
                        : null)
                .build();
    }
}