package com.cognizant.civicaid.service;

import java.util.Map;

public interface ReportService {
    Map<String, Object> getDashboardStats();
    Map<String, Object> getApplicationStats();
    Map<String, Object> getDisbursementStats();
    Map<String, Object> getComplianceStats();
    Map<String, Object> getProgramStats(Long programId);
}
