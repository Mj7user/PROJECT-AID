package com.cognizant.DisbursementAndPaymentService.Service;

import com.cognizant.DisbursementAndPaymentService.Entity.Disbursement;
import com.cognizant.DisbursementAndPaymentService.Request.DisbursementRequest;
import com.cognizant.DisbursementAndPaymentService.Response.DisbursementResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface DisbursementService {

    DisbursementResponse createDisbursement(DisbursementRequest request);

    DisbursementResponse getById(Long id);

    List<DisbursementResponse> getByApplication(Long applicationId);

    Page<DisbursementResponse> getByStatus(
            Disbursement.DisbursementStatus status,
            Pageable pageable
    );

    Page<DisbursementResponse> getAll(Pageable pageable);

    DisbursementResponse updateStatus(
            Long id,
            Disbursement.DisbursementStatus status
    );
}
