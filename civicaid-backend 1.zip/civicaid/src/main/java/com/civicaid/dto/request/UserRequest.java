package com.civicaid.dto.request;

import com.civicaid.entity.User;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class UserRequest {
    @NotBlank
    private String name;
    @NotBlank @Email
    private String email;
    private String phone;
    private User.Role role;
    private User.UserStatus status;
}
