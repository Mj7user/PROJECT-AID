package com.cognizant.civicaid.controller;

import com.cognizant.civicaid.dto.request.ComplianceRecordRequest;
import com.cognizant.civicaid.dto.response.ComplianceRecordResponse;
import com.cognizant.civicaid.entity.ComplianceRecord;
import com.cognizant.civicaid.entity.User;
import com.cognizant.civicaid.exception.ResourceNotFoundException;
import com.cognizant.civicaid.repository.UserRepository;
import com.cognizant.civicaid.service.ComplianceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/compliance")
@RequiredArgsConstructor
@Slf4j
public class ComplianceController {

    private final ComplianceService complianceService;
    private final UserRepository userRepository;

    @PostMapping
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<ComplianceRecordResponse> createRecord(
            @AuthenticationPrincipal UserDetails userDetails,
            @Valid @RequestBody ComplianceRecordRequest request) {

        log.info("Create Compliance Record request received by user: {}",
                userDetails.getUsername());

        User reviewer = userRepository.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> {
                    log.error("User not found for email: {}", userDetails.getUsername());
                    return new ResourceNotFoundException("User not found");
                });

        ComplianceRecordResponse response =
                complianceService.createRecord(reviewer.getUserId(), request);

        log.info("Compliance Record created successfully with ID:{}",reviewer.getUserId());

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','ADMINISTRATOR','GOVERNMENT_AUDITOR')")
    public ResponseEntity<ComplianceRecordResponse> getRecordById(@PathVariable Long id) {

        log.debug("Fetching Compliance Record with ID: {}", id);

        ComplianceRecordResponse response =
                complianceService.getRecordById(id);

        log.info("Compliance Record fetched successfully for ID: {}", id);
        return ResponseEntity.ok(response);
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','ADMINISTRATOR','GOVERNMENT_AUDITOR')")
    public ResponseEntity<Page<ComplianceRecordResponse>> getAllRecords(
            @PageableDefault(size = 20) Pageable pageable,
            @RequestParam(required = false) ComplianceRecord.ComplianceResult result) {

        log.debug("Fetching Compliance Records | result: {} | page: {} | size: {}",
                result, pageable.getPageNumber(), pageable.getPageSize());

        Page<ComplianceRecordResponse> page = result != null
                ? complianceService.getRecordsByResult(result, pageable)
                : complianceService.getAllRecords(pageable);

        log.info("Fetched {} compliance records", page.getTotalElements());
        return ResponseEntity.ok(page);
    }

    @GetMapping("/entity/{entityId}")
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','ADMINISTRATOR','GOVERNMENT_AUDITOR')")
    public ResponseEntity<List<ComplianceRecordResponse>> getRecordsByEntity(
            @PathVariable Long entityId,
            @RequestParam ComplianceRecord.EntityType type) {

        log.debug("Fetching Compliance Records for entity | ID: {} | Type: {}",
                entityId, type);

        List<ComplianceRecordResponse> responses =
                complianceService.getRecordsByEntity(entityId, type);

        log.info("Fetched {} compliance records for entity ID: {}",
                responses.size(), entityId);

        return ResponseEntity.ok(responses);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<ComplianceRecordResponse> updateRecord(
            @PathVariable Long id,
            @Valid @RequestBody ComplianceRecordRequest request) {

        log.info("Update Compliance Record request received | ID: {}", id);

        ComplianceRecordResponse response =
                complianceService.updateRecord(id, request);

        log.info("Compliance Record updated successfully | ID: {}", id);
        return ResponseEntity.ok(response);
    }
}