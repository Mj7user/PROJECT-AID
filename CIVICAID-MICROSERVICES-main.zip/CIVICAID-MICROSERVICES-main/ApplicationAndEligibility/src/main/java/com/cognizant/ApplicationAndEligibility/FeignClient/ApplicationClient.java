package com.cognizant.ApplicationAndEligibility.FeignClient;

@FeignClient(name = "application-service")
public interface ApplicationClient {

    @GetMapping("/applications/{applicationId}")
    ApplicationDTO getApplication(@PathVariable Long applicationId);
}
