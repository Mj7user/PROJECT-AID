import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { Role } from '../../../models/user.model';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
  name = '';
  email = '';
  password = '';
  phone = '';
  role: Role = 'CITIZEN';
  error = '';
  success = '';
  loading = false;

  roles: { value: Role; label: string }[] = [
    { value: 'CITIZEN', label: 'Citizen' },
    { value: 'WELFARE_OFFICER', label: 'Welfare Officer' },
    { value: 'PROGRAM_MANAGER', label: 'Program Manager' },
    { value: 'ADMINISTRATOR', label: 'Administrator' },
    { value: 'COMPLIANCE_OFFICER', label: 'Compliance Officer' },
    { value: 'GOVERNMENT_AUDITOR', label: 'Government Auditor' }
  ];

  constructor(private authService: AuthService, private router: Router) {}

  register() {
    if (!this.name || !this.email || !this.password) {
      this.error = 'Name, email and password are required';
      return;
    }
    if (this.password.length < 6) {
      this.error = 'Password must be at least 6 characters';
      return;
    }
    this.loading = true;
    this.error = '';
    this.success = '';

    this.authService.register({
      name: this.name,
      email: this.email,
      password: this.password,
      phone: this.phone || undefined,
      role: this.role
    }).subscribe({
      next: () => {
        this.success = 'Registration successful! Redirecting to login...';
        setTimeout(() => this.router.navigate(['/login']), 2000);
      },
      error: (err) => {
        this.loading = false;
        this.error = err.error?.message || 'Registration failed. Please try again.';
      }
    });
  }
}
