package com.cognizant.ApplicationAndEligibility.response;

import com.cognizant.ApplicationAndEligibility.entity.WelfareApplication;
import lombok.*;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WelfareApplicationResponse {

    private Long applicationId;
    private Long citizenId;
    private Long programId;
    private Long schemeId;
    private LocalDateTime submittedDate;
    private WelfareApplication.ApplicationStatus status;
    private String remarks;
    private LocalDateTime updatedAt;
}