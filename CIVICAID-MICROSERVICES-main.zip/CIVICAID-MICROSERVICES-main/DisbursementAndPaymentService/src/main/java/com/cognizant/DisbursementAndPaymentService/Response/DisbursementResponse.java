package com.cognizant.DisbursementAndPaymentService.Response;


import com.cognizant.DisbursementAndPaymentService.Entity.Disbursement;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class DisbursementResponse {
    private Long disbursementId;
    private Long applicationId;
    private Long citizenId;
    private Long programId;
    private BigDecimal amount;
    private Disbursement.DisbursementStatus status;
    private String remarks;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}