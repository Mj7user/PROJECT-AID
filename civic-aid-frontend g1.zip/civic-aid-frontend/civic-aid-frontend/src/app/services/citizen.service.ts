import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CitizenRequest, CitizenResponse, CitizenStatus } from '../models/citizen.model';
import { Page } from '../models/program.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class CitizenService {
  private apiUrl = `${environment.apiGatewayUrl}/citizens`;

  constructor(private http: HttpClient) {}

  registerCitizen(request: CitizenRequest): Observable<CitizenResponse> {
    return this.http.post<CitizenResponse>(this.apiUrl, request);
  }

  getCitizenById(id: number): Observable<CitizenResponse> {
    return this.http.get<CitizenResponse>(`${this.apiUrl}/${id}`);
  }

  updateCitizen(id: number, request: CitizenRequest): Observable<CitizenResponse> {
    return this.http.put<CitizenResponse>(`${this.apiUrl}/${id}`, request);
  }

  getAllCitizens(page: number = 0, size: number = 10, search?: string): Observable<Page<CitizenResponse>> {
    let params = new HttpParams().set('page', page).set('size', size);
    if (search) params = params.set('search', search);
    return this.http.get<Page<CitizenResponse>>(this.apiUrl, { params });
  }

  updateCitizenStatus(id: number, status: CitizenStatus): Observable<string> {
    const params = new HttpParams().set('status', status);
    return this.http.patch(`${this.apiUrl}/${id}/status`, null, { params, responseType: 'text' });
  }
}
