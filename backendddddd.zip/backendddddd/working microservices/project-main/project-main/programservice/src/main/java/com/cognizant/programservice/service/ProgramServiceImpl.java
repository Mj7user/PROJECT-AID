package com.cognizant.programservice.service;
import com.cognizant.programservice.dao.ProgramRepository;
import com.cognizant.programservice.dao.SchemeRepository;
import com.cognizant.programservice.dto.*; 
import com.cognizant.programservice.entity.Program; 
import com.cognizant.programservice.exception.ResourceNotFoundException;
import com.cognizant.programservice.exception.BusinessException;
import lombok.RequiredArgsConstructor; 
import org.springframework.stereotype.Service; 
import java.util.List; 
import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class ProgramServiceImpl implements ProgramService {
    private final ProgramRepository programRepository;
    private final SchemeRepository schemeRepository;
    @Override public ProgramResponseDto createProgram(ProgramRequestDto dto) {
        Program p = Program.builder().title(dto.getTitle()).description(dto.getDescription()).startDate(dto.getStartDate()).endDate(dto.getEndDate()).budget(dto.getBudget()).build();
        return toDto(programRepository.save(p));
    }
    @Override public ProgramResponseDto getProgramById(Long id) { return toDto(programRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Program not found: " + id))); }
    @Override public List<ProgramResponseDto> getAllPrograms() { return programRepository.findAll().stream().map(this::toDto).collect(Collectors.toList()); }
    @Override public ProgramResponseDto updateProgram(Long id, ProgramRequestDto dto) {
        Program p = programRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Program not found: " + id));
        p.setTitle(dto.getTitle()); p.setDescription(dto.getDescription()); p.setStartDate(dto.getStartDate()); p.setEndDate(dto.getEndDate()); p.setBudget(dto.getBudget());
        if (dto.getStatus() != null) p.setStatus(dto.getStatus());
        return toDto(programRepository.save(p));
    }
    @Override public void deleteProgram(Long id) {
        programRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Program not found: " + id));
        var activeSchemes = schemeRepository.findActiveSchemesByProgramId(id);
        if (!activeSchemes.isEmpty()) {
            throw new BusinessException("Deletion unsuccessful: Program has " + activeSchemes.size() + " active scheme(s). All schemes must be inactive or completed before deletion.");
        }
        // Delete all associated schemes first to avoid foreign key constraint violation
        var allSchemes = schemeRepository.findByProgram_ProgramId(id);
        schemeRepository.deleteAll(allSchemes);
        // Now delete the program
        programRepository.deleteById(id);
    }
    private ProgramResponseDto toDto(Program p) { return ProgramResponseDto.builder().programId(p.getProgramId()).title(p.getTitle()).description(p.getDescription()).startDate(p.getStartDate()).endDate(p.getEndDate()).budget(p.getBudget()).status(p.getStatus()).createdAt(p.getCreatedAt()).build(); }
}
