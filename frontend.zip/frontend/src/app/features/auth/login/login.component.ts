import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { UserService } from '../../../core/services/user.service';
import { Role } from '../../../core/models/role.enum';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private userService = inject(UserService);
  private router = inject(Router);

  loginForm: FormGroup = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]]
  });

  loading = false;
  errorMsg = '';

  isInvalid(field: string): boolean {
    const ctrl = this.loginForm.get(field);
    return !!(ctrl && ctrl.invalid && ctrl.touched);
  }

  onSubmit(): void {
    if (this.loginForm.invalid) { this.loginForm.markAllAsTouched(); return; }
    this.loading = true;
    this.errorMsg = '';

    this.authService.login(this.loginForm.value).subscribe({
      next: (response) => {
        // After login, resolve the userId from the backend.
        // Strategy depends on the user's role:
        //
        // Officers/Admins: GET /users/getallusers → find by email → extract userId
        // Citizens: GET /users/getallusers is 403, so we try it and if it fails,
        //           the dashboard will still attempt /citizens/user/{userId} once
        //           userId becomes available. As a fallback, we search all users
        //           but gracefully handle failure.
        //
        // NOTE: The backend's GET /users/email/{email} returns UserDto which has
        // NO userId field (only email, role, password). This is a backend limitation.
        // The ideal fix is adding userId to LoginResponseDto on the backend side.

        this.resolveUserId(response.email, response.role);
      },
      error: (err) => {
        this.errorMsg = err.error?.message || err.error || 'Invalid credentials. Please try again.';
        this.loading = false;
      }
    });
  }

  private resolveUserId(email: string, role: string): void {
    // For all roles: try GET /users/getallusers to find userId by email.
    // If this returns 403 (e.g. CITIZEN role doesn't have permission),
    // we fall back gracefully — the dashboard will work without userId
    // for officer features, but citizen-specific features will be limited
    // until the backend adds userId to the login response.
    this.userService.getAllUsers().subscribe({
      next: (users) => {
        const match = users.find(u => u.email === email);
        if (match) {
          this.authService.setUserId(match.userId);
        }
        this.router.navigate(['/dashboard']);
        this.loading = false;
      },
      error: () => {
        // Fallback: if CITIZEN can't access /users/getallusers,
        // still navigate to dashboard. The citizen dashboard will attempt
        // to resolve userId via other means if needed.
        this.router.navigate(['/dashboard']);
        this.loading = false;
      }
    });
  }
}
