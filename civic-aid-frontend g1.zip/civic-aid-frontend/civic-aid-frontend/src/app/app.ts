import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from './components/layout/sidebar/sidebar.component';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule, SidebarComponent],
  template: `
    <div class="app-container" [class.with-sidebar]="authService.isLoggedIn()">
      <app-sidebar *ngIf="authService.isLoggedIn()"></app-sidebar>
      <main class="main-content" [class.full-width]="!authService.isLoggedIn()">
        <router-outlet></router-outlet>
      </main>
    </div>
  `,
  styles: [`
    .app-container {
      display: flex;
      min-height: 100vh;
    }
    .main-content {
      flex: 1;
      overflow-y: auto;
      height: 100vh;
    }
    .main-content.full-width {
      width: 100%;
    }
  `]
})
export class App {
  constructor(public authService: AuthService) {}
}
