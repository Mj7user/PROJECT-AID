package com.cognizant.applicationservice.externalservice;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "citizen-service")
public interface CitizenServiceClient {

    @GetMapping("/citizens/{id}")
    Object getCitizenById(@PathVariable Long id);
}
