package com.cognizant.authentication.service;

import com.cognizant.authentication.dto.LoginRequestDto;
import com.cognizant.authentication.dto.LoginResponseDto;
import com.cognizant.authentication.dto.RegisterRequestDto;
import com.cognizant.authentication.dto.RegisterResponseDto;

public interface AuthService {

    RegisterResponseDto createUsers(RegisterRequestDto registerRequestDto);
    LoginResponseDto login(LoginRequestDto loginRequestDto);
}
