package com.cognizant.Report.FeignClient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Map;

@FeignClient(name = "citizen-service", path = "/citizens")
public interface CitizenFeignClient {

    @GetMapping("/stats")
    Map<String, Object> getCitizenStats();
}