package com.cognizant.ApplicationAndEligibility.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "EligibilityChecks")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EligibilityCheck {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long checkId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "application_id", nullable = false)
    private WelfareApplication application; // ✅ CORRECT ENTITY

    @Column(nullable = false)
    private Long officerId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CheckResult result;

    @CreationTimestamp
    private LocalDateTime date;

    @Column(columnDefinition = "TEXT")
    private String notes;

    public enum CheckResult {
        ELIGIBLE,
        INELIGIBLE,
        PENDING_DOCUMENTS,
        FURTHER_REVIEW
    }
}