package com.cognizant.civicaid.service.impl;

import com.cognizant.civicaid.dto.request.PaymentRequest;
import com.cognizant.civicaid.dto.response.PaymentResponse;
import com.cognizant.civicaid.entity.Disbursement;
import com.cognizant.civicaid.entity.Notification;
import com.cognizant.civicaid.entity.Payment;
import com.cognizant.civicaid.exception.ResourceNotFoundException;
import com.cognizant.civicaid.repository.DisbursementRepository;
import com.cognizant.civicaid.repository.PaymentRepository;
import com.cognizant.civicaid.service.NotificationService;
import com.cognizant.civicaid.service.PaymentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final DisbursementRepository disbursementRepository;
    private final NotificationService notificationService;

    @Override
    @Transactional
    public PaymentResponse initiatePayment(PaymentRequest request) {

        log.info("Initiating payment | disbursementId={} | amount={} | method={}",
                request.getDisbursementId(),
                request.getAmount(),
                request.getMethod());

        Disbursement disbursement = disbursementRepository
                .findById(request.getDisbursementId())
                .orElseThrow(() -> {
                    log.error("Disbursement not found | disbursementId={}",
                            request.getDisbursementId());
                    return new ResourceNotFoundException(
                            "Disbursement", request.getDisbursementId());
                });

        Payment payment = Payment.builder()
                .disbursement(disbursement)
                .method(request.getMethod())
                .amount(request.getAmount())
                .bankAccountNumber(request.getBankAccountNumber())
                .walletId(request.getWalletId())
                .transactionReference(request.getTransactionReference())
                .status(Payment.PaymentStatus.INITIATED)
                .build();

        payment = paymentRepository.save(payment);

        log.info("Payment created successfully | paymentId={}", payment.getPaymentId());

        disbursement.setStatus(Disbursement.DisbursementStatus.PROCESSING);
        disbursementRepository.save(disbursement);

        log.info("Disbursement moved to PROCESSING | disbursementId={}",
                disbursement.getDisbursementId());

        notificationService.sendNotification(
                disbursement.getApplication().getCitizen().getUser().getUserId(),
                payment.getPaymentId(),
                "Payment of ₹" + request.getAmount()
                        + " initiated via " + request.getMethod().name(),
                Notification.NotificationCategory.DISBURSEMENT
        );

        log.info("Payment initiation notification sent | paymentId={}", payment.getPaymentId());

        return mapToResponse(payment);
    }

    @Override
    public PaymentResponse getPaymentById(Long id) {

        log.debug("Fetching payment | paymentId={}", id);

        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Payment not found | paymentId={}", id);
                    return new ResourceNotFoundException("Payment", id);
                });

        return mapToResponse(payment);
    }

    @Override
    public List<PaymentResponse> getPaymentsByDisbursement(Long disbursementId) {

        log.debug("Fetching payments for disbursement | disbursementId={}", disbursementId);

        List<PaymentResponse> list =
                paymentRepository
                        .findByDisbursement_DisbursementId(disbursementId)
                        .stream()
                        .map(this::mapToResponse)
                        .toList();

        log.info("Fetched {} payments | disbursementId={}",
                list.size(), disbursementId);

        return list;
    }

    @Override
    public Page<PaymentResponse> getAllPayments(Pageable pageable) {

        log.debug("Fetching all payments | page={} | size={}",
                pageable.getPageNumber(), pageable.getPageSize());

        Page<PaymentResponse> page =
                paymentRepository.findAll(pageable).map(this::mapToResponse);

        log.info("Fetched {} payments", page.getTotalElements());
        return page;
    }

    @Override
    @Transactional
    public PaymentResponse updatePaymentStatus(Long id, Payment.PaymentStatus status) {

        log.info("Updating payment status | paymentId={} | newStatus={}", id, status);

        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Payment not found for status update | paymentId={}", id);
                    return new ResourceNotFoundException("Payment", id);
                });

        payment.setStatus(status);

        if (status == Payment.PaymentStatus.SUCCESS) {

            Disbursement disbursement = payment.getDisbursement();
            disbursement.setStatus(Disbursement.DisbursementStatus.COMPLETED);
            disbursementRepository.save(disbursement);

            log.info("Disbursement completed | disbursementId={}",
                    disbursement.getDisbursementId());

            notificationService.sendNotification(
                    disbursement.getApplication().getCitizen().getUser().getUserId(),
                    payment.getPaymentId(),
                    "Payment of ₹" + payment.getAmount()
                            + " completed successfully.",
                    Notification.NotificationCategory.DISBURSEMENT
            );

            log.info("Payment success notification sent | paymentId={}",
                    payment.getPaymentId());
        }

        Payment updatedPayment = paymentRepository.save(payment);

        log.info("Payment status updated successfully | paymentId={} | status={}",
                updatedPayment.getPaymentId(), updatedPayment.getStatus());

        return mapToResponse(updatedPayment);
    }

    private PaymentResponse mapToResponse(Payment p) {
        return PaymentResponse.builder()
                .paymentId(p.getPaymentId())
                .disbursementId(p.getDisbursement().getDisbursementId())
                .method(p.getMethod())
                .amount(p.getAmount())
                .transactionReference(p.getTransactionReference())
                .bankAccountNumber(p.getBankAccountNumber())
                .walletId(p.getWalletId())
                .date(p.getDate())
                .status(p.getStatus())
                .updatedAt(p.getUpdatedAt())
                .build();
    }
}