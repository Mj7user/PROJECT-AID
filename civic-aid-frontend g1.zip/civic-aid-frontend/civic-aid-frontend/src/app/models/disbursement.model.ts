export type DisbursementStatus = 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';

export interface DisbursementRequest {
  applicationId: number;
  citizenId: number;
  programId: number;
  amount: number;
  remarks?: string;
}

export interface DisbursementResponse {
  disbursementId: number;
  applicationId: number;
  citizenId: number;
  programId: number;
  amount: number;
  status: DisbursementStatus;
  remarks: string;
  createdAt: string;
  updatedAt: string;
}
