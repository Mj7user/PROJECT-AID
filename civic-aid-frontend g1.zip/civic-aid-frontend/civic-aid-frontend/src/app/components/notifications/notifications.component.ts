import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationService } from '../../services/notification.service';
import { NotificationResponse } from '../../models/notification.model';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent implements OnInit {
  notifications: NotificationResponse[] = [];
  loading = true;
  currentPage = 0;
  totalPages = 0;
  unreadCount = 0;
  recipientId = 1; // Would come from logged-in user
  success = '';

  constructor(private notifService: NotificationService, private authService: AuthService) {}

  ngOnInit() {
    this.load();
    this.loadUnreadCount();
  }

  load() {
    this.loading = true;
    this.notifService.getNotifications(this.recipientId, this.currentPage).subscribe({
      next: (page) => { this.notifications = page.content; this.totalPages = page.totalPages; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  loadUnreadCount() {
    this.notifService.getUnreadCount(this.recipientId).subscribe({
      next: (count) => this.unreadCount = count,
      error: () => {}
    });
  }

  markAsRead(id: number) {
    this.notifService.markAsRead(id).subscribe({ next: () => { this.load(); this.loadUnreadCount(); } });
  }

  markAllAsRead() {
    this.notifService.markAllAsRead(this.recipientId).subscribe({
      next: () => { this.success = 'All notifications marked as read'; this.load(); this.loadUnreadCount(); setTimeout(() => this.success = '', 3000); }
    });
  }

  deleteNotification(id: number) {
    this.notifService.deleteNotification(id).subscribe({ next: () => this.load() });
  }

  getCategoryClass(c: string): string {
    const m: Record<string, string> = { 'APPLICATION': 'badge-info', 'DISBURSEMENT': 'badge-success', 'COMPLIANCE': 'badge-warning', 'SYSTEM': 'badge-danger', 'GENERAL': 'badge-muted' };
    return m[c] || 'badge-muted';
  }

  formatDate(d: string): string { return d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '-'; }
  prevPage() { if (this.currentPage > 0) { this.currentPage--; this.load(); } }
  nextPage() { if (this.currentPage < this.totalPages - 1) { this.currentPage++; this.load(); } }
}
