import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ComplianceService } from '../../services/compliance.service';
import { AuditResponse, AuditRequest, AuditStatus } from '../../models/compliance.model';

@Component({
  selector: 'app-audits',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './audits.component.html',
  styleUrls: ['./audits.component.scss']
})
export class AuditsComponent implements OnInit {
  audits: AuditResponse[] = [];
  loading = true; showModal = false; currentPage = 0; totalPages = 0;
  filterStatus: AuditStatus | '' = '';
  formData: AuditRequest = { scope: '', status: 'SCHEDULED' };
  officerId = 0;
  statuses: AuditStatus[] = ['SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'PENDING_REVIEW', 'CLOSED'];
  error = ''; success = '';

  constructor(private service: ComplianceService) {}
  ngOnInit() { this.load(); }

  load() {
    this.loading = true;
    this.service.getAllAudits(this.currentPage, 20, this.filterStatus || undefined).subscribe({
      next: (page) => { this.audits = page.content; this.totalPages = page.totalPages; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  openCreate() { this.formData = { scope: '', status: 'SCHEDULED' }; this.officerId = 0; this.error = ''; this.showModal = true; }

  create() {
    if (!this.formData.scope || !this.officerId) { this.error = 'Scope and Officer ID are required'; return; }
    this.service.createAudit(this.officerId, this.formData).subscribe({
      next: () => { this.showModal = false; this.success = 'Audit created'; this.load(); setTimeout(() => this.success = '', 3000); },
      error: (err) => { this.error = err.error?.message || 'Failed'; }
    });
  }

  onFilterChange() { this.currentPage = 0; this.load(); }

  getStatusClass(s: string): string {
    const m: Record<string, string> = { 'SCHEDULED': 'badge-info', 'IN_PROGRESS': 'badge-warning', 'COMPLETED': 'badge-success', 'PENDING_REVIEW': 'badge-primary', 'CLOSED': 'badge-muted' };
    return m[s] || 'badge-muted';
  }

  formatDate(d: string): string { return d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'; }
  prevPage() { if (this.currentPage > 0) { this.currentPage--; this.load(); } }
  nextPage() { if (this.currentPage < this.totalPages - 1) { this.currentPage++; this.load(); } }
}
