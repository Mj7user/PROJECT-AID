package com.cognizant.applicationservice.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "eligibility_checks")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class EligibilityCheck {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long checkId;

    @Column(nullable = false)
    private Long applicationId;

    @Column(nullable = false)
    private Long officerId;

    @Enumerated(EnumType.STRING)
    private CheckResult result;

    @Builder.Default
    private LocalDate date = LocalDate.now();

    @Column(columnDefinition = "TEXT")
    private String notes;

    @CreationTimestamp
    private LocalDateTime createdAt;

    public enum CheckResult { ELIGIBLE, INELIGIBLE, PENDING }
}
