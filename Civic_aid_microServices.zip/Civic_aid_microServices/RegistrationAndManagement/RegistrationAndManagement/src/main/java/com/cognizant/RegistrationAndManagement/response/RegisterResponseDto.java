package com.cognizant.RegistrationAndManagement.response;

import com.cognizant.RegistrationAndManagement.enums.Role;
import com.cognizant.RegistrationAndManagement.enums.Status;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegisterResponseDto {

    private Long userId;
    private String name;
    private String email;
    private String phone;
    private Role role;
    private Status status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

}
