package com.cognizant.DisbursementAndPaymentService.Controller;

import com.cognizant.DisbursementAndPaymentService.Entity.Payment;
import com.cognizant.DisbursementAndPaymentService.Request.PaymentRequest;
import com.cognizant.DisbursementAndPaymentService.Response.PaymentResponse;
import com.cognizant.DisbursementAndPaymentService.Service.PaymentService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping
    public ResponseEntity<PaymentResponse> initiatePayment(
            @Valid @RequestBody PaymentRequest request) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(paymentService.initiatePayment(request));
    }

    @GetMapping("/disbursement/{disbursementId}")
    public ResponseEntity<List<PaymentResponse>> getByDisbursement(
            @PathVariable Long disbursementId) {

        return ResponseEntity.ok(
                paymentService.getByDisbursement(disbursementId)
        );
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<PaymentResponse> updateStatus(
            @PathVariable Long id,
            @RequestParam Payment.PaymentStatus status) {

        return ResponseEntity.ok(
                paymentService.updateStatus(id, status)
        );
    }
}