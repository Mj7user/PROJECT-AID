import { Routes } from '@angular/router';
import { authGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  {
    path: 'login',
    loadComponent: () => import('./components/auth/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'register',
    loadComponent: () => import('./components/auth/register/register.component').then(m => m.RegisterComponent)
  },
  {
    path: 'dashboard',
    loadComponent: () => import('./components/dashboard/dashboard.component').then(m => m.DashboardComponent),
    canActivate: [authGuard]
  },
  {
    path: 'programs',
    loadComponent: () => import('./components/programs/programs.component').then(m => m.ProgramsComponent),
    canActivate: [authGuard]
  },
  {
    path: 'schemes',
    loadComponent: () => import('./components/schemes/schemes.component').then(m => m.SchemesComponent),
    canActivate: [authGuard]
  },
  {
    path: 'applications',
    loadComponent: () => import('./components/applications/applications.component').then(m => m.ApplicationsComponent),
    canActivate: [authGuard]
  },
  {
    path: 'citizens',
    loadComponent: () => import('./components/citizens/citizens.component').then(m => m.CitizensComponent),
    canActivate: [authGuard]
  },
  {
    path: 'disbursements',
    loadComponent: () => import('./components/disbursements/disbursements.component').then(m => m.DisbursementsComponent),
    canActivate: [authGuard]
  },
  {
    path: 'compliance',
    loadComponent: () => import('./components/compliance/compliance.component').then(m => m.ComplianceComponent),
    canActivate: [authGuard]
  },
  {
    path: 'audits',
    loadComponent: () => import('./components/audits/audits.component').then(m => m.AuditsComponent),
    canActivate: [authGuard]
  },
  {
    path: 'users',
    loadComponent: () => import('./components/users/users.component').then(m => m.UsersComponent),
    canActivate: [authGuard],
    data: { roles: ['ADMINISTRATOR', 'WELFARE_OFFICER', 'PROGRAM_MANAGER'] }
  },
  {
    path: 'notifications',
    loadComponent: () => import('./components/notifications/notifications.component').then(m => m.NotificationsComponent),
    canActivate: [authGuard]
  },
  { path: '**', redirectTo: '/dashboard' }
];
