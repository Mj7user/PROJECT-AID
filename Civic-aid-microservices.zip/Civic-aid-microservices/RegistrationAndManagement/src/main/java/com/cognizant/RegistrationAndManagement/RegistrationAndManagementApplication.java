package com.cognizant.RegistrationAndManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrationAndManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationAndManagementApplication.class, args);
	}

}
