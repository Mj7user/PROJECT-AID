import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProgramService } from '../../services/program.service';
import { ProgramRequest, ProgramResponse, ProgramStatus } from '../../models/program.model';

@Component({
  selector: 'app-programs',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './programs.component.html',
  styleUrls: ['./programs.component.scss']
})
export class ProgramsComponent implements OnInit {
  programs: ProgramResponse[] = [];
  loading = true;
  showModal = false;
  currentPage = 0;
  totalPages = 0;

  formData: ProgramRequest = { title: '', description: '', startDate: '', budget: 0 };
  statuses: ProgramStatus[] = ['DRAFT', 'ACTIVE', 'INACTIVE', 'PAUSED', 'COMPLETED', 'CANCELLED'];
  error = '';
  success = '';

  constructor(private programService: ProgramService) {}

  ngOnInit() { this.loadPrograms(); }

  loadPrograms() {
    this.loading = true;
    this.programService.getAllPrograms(this.currentPage).subscribe({
      next: (page) => {
        this.programs = page.content;
        this.totalPages = page.totalPages;
        this.loading = false;
      },
      error: () => { this.loading = false; }
    });
  }

  openCreate() {
    this.formData = { title: '', description: '', startDate: '', budget: 0, status: 'DRAFT' };
    this.error = '';
    this.showModal = true;
  }

  createProgram() {
    if (!this.formData.title || !this.formData.startDate || !this.formData.budget) {
      this.error = 'Title, start date, and budget are required';
      return;
    }
    this.programService.createProgram(this.formData).subscribe({
      next: () => {
        this.showModal = false;
        this.success = 'Program created successfully';
        this.loadPrograms();
        setTimeout(() => this.success = '', 3000);
      },
      error: (err) => { this.error = err.error?.message || 'Failed to create program'; }
    });
  }

  getStatusClass(status: string): string {
    const map: Record<string, string> = {
      'ACTIVE': 'badge-success', 'DRAFT': 'badge-info', 'INACTIVE': 'badge-muted',
      'PAUSED': 'badge-warning', 'COMPLETED': 'badge-primary', 'CANCELLED': 'badge-danger'
    };
    return map[status] || 'badge-muted';
  }

  formatCurrency(v: number): string {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(v);
  }

  formatDate(d: string): string {
    return d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '-';
  }

  prevPage() { if (this.currentPage > 0) { this.currentPage--; this.loadPrograms(); } }
  nextPage() { if (this.currentPage < this.totalPages - 1) { this.currentPage++; this.loadPrograms(); } }
}
