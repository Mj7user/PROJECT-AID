import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProgramService } from '../../services/program.service';
import { SchemeRequest, SchemeResponse } from '../../models/program.model';

@Component({
  selector: 'app-schemes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './schemes.component.html',
  styleUrls: ['./schemes.component.scss']
})
export class SchemesComponent implements OnInit {
  schemes: SchemeResponse[] = [];
  loading = true;
  showModal = false;
  currentPage = 0;
  totalPages = 0;
  formData: SchemeRequest = { programId: 0, title: '', description: '', eligibilityCriteria: '' };
  error = '';
  success = '';

  constructor(private programService: ProgramService) {}

  ngOnInit() { this.loadSchemes(); }

  loadSchemes() {
    this.loading = true;
    this.programService.getAllSchemes(this.currentPage).subscribe({
      next: (page) => { this.schemes = page.content; this.totalPages = page.totalPages; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  openCreate() { this.formData = { programId: 0, title: '', description: '', eligibilityCriteria: '', status: 'ACTIVE' }; this.error = ''; this.showModal = true; }

  createScheme() {
    if (!this.formData.title || !this.formData.programId) { this.error = 'Title and program ID are required'; return; }
    this.programService.createScheme(this.formData).subscribe({
      next: () => { this.showModal = false; this.success = 'Scheme created successfully'; this.loadSchemes(); setTimeout(() => this.success = '', 3000); },
      error: (err) => { this.error = err.error?.message || 'Failed to create scheme'; }
    });
  }

  deleteScheme(id: number) {
    if (confirm('Are you sure you want to delete this scheme?')) {
      this.programService.deleteScheme(id).subscribe({ next: () => this.loadSchemes() });
    }
  }

  getStatusClass(s: string): string {
    return s === 'ACTIVE' ? 'badge-success' : s === 'INACTIVE' ? 'badge-muted' : 'badge-warning';
  }

  formatDate(d: string): string { return d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'; }
  prevPage() { if (this.currentPage > 0) { this.currentPage--; this.loadSchemes(); } }
  nextPage() { if (this.currentPage < this.totalPages - 1) { this.currentPage++; this.loadSchemes(); } }
}
