import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CitizenService } from '../../services/citizen.service';
import { CitizenResponse, CitizenRequest } from '../../models/citizen.model';

@Component({
  selector: 'app-citizens',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './citizens.component.html',
  styleUrls: ['./citizens.component.scss']
})
export class CitizensComponent implements OnInit {
  citizens: CitizenResponse[] = [];
  loading = true;
  showModal = false;
  currentPage = 0;
  totalPages = 0;
  searchQuery = '';
  formData: CitizenRequest = { userId: 0, name: '', dob: '' };
  error = '';
  success = '';

  constructor(private citizenService: CitizenService) {}
  ngOnInit() { this.loadCitizens(); }

  loadCitizens() {
    this.loading = true;
    this.citizenService.getAllCitizens(this.currentPage, 10, this.searchQuery || undefined).subscribe({
      next: (page) => { this.citizens = page.content; this.totalPages = page.totalPages; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  search() { this.currentPage = 0; this.loadCitizens(); }

  openCreate() { this.formData = { userId: 0, name: '', dob: '' }; this.error = ''; this.showModal = true; }

  registerCitizen() {
    if (!this.formData.userId || !this.formData.name || !this.formData.dob) { this.error = 'User ID, name, and DOB are required'; return; }
    this.citizenService.registerCitizen(this.formData).subscribe({
      next: () => { this.showModal = false; this.success = 'Citizen registered'; this.loadCitizens(); setTimeout(() => this.success = '', 3000); },
      error: (err) => { this.error = err.error?.message || 'Registration failed'; }
    });
  }

  updateStatus(id: number, status: 'PENDING' | 'VERIFIED' | 'REJECTED' | 'SUSPENDED') {
    this.citizenService.updateCitizenStatus(id, status).subscribe({ next: () => { this.success = 'Status updated'; this.loadCitizens(); setTimeout(() => this.success = '', 3000); } });
  }

  getStatusClass(s: string): string {
    const m: Record<string, string> = { 'PENDING': 'badge-warning', 'VERIFIED': 'badge-success', 'REJECTED': 'badge-danger', 'SUSPENDED': 'badge-muted' };
    return m[s] || 'badge-muted';
  }

  formatDate(d: string): string { return d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'; }
  prevPage() { if (this.currentPage > 0) { this.currentPage--; this.loadCitizens(); } }
  nextPage() { if (this.currentPage < this.totalPages - 1) { this.currentPage++; this.loadCitizens(); } }
}
