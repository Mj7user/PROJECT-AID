package com.cognizant.Report.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "program_report")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProgramReport {

    @Id
    private Long programId;

    @Column(nullable = false)
    private String programName;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ProgramStatus status;

    @Column(nullable = false, precision = 15, scale = 2)
    private BigDecimal budget;

    public enum ProgramStatus {
        ACTIVE,
        INACTIVE,
        COMPLETED,
        CANCELLED
    }
}