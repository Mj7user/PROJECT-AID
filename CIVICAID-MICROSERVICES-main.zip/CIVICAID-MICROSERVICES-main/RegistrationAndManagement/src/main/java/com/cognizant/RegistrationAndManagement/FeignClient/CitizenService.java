package com.cognizant.RegistrationAndManagement.FeignClient;

