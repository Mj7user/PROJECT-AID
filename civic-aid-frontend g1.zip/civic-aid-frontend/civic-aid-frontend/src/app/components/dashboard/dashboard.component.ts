import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReportService } from '../../services/report.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  stats: Record<string, any> = {};
  loading = true;
  userRole = '';
  greeting = '';

  constructor(private reportService: ReportService, private authService: AuthService) {}

  ngOnInit() {
    this.userRole = this.authService.getUserRole() || '';
    this.setGreeting();
    this.loadDashboard();
  }

  loadDashboard() {
    this.reportService.getDashboardStats().subscribe({
      next: (data) => {
        this.stats = data;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
        // Use sample data when backend is unavailable
        this.stats = {
          totalPrograms: 12,
          totalApplications: 156,
          totalDisbursements: 89,
          totalCitizens: 2340,
          pendingApplications: 34,
          approvedApplications: 98,
          totalBudget: 15000000,
          disbursedAmount: 8750000
        };
      }
    });
  }

  setGreeting() {
    const hour = new Date().getHours();
    if (hour < 12) this.greeting = 'Good Morning';
    else if (hour < 17) this.greeting = 'Good Afternoon';
    else this.greeting = 'Good Evening';
  }

  getStatValue(key: string): number {
    return this.stats[key] || 0;
  }

  formatCurrency(value: number): string {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);
  }
}
