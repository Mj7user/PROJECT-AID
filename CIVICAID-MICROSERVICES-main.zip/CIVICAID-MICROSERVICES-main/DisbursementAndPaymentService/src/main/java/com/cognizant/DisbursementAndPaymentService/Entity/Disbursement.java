package com.cognizant.DisbursementAndPaymentService.Entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "Disbursements")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Disbursement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long disbursementId;

    @Column(nullable = false)
    private Long applicationId;

    @Column(nullable = false)
    private Long citizenId;

    @Column(nullable = false)
    private Long programId;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private DisbursementStatus status = DisbursementStatus.PENDING;

    @Column(columnDefinition = "TEXT")
    private String remarks;

    @OneToMany(mappedBy = "disbursement", cascade = CascadeType.ALL)
    private List<Payment> payments;

    @CreationTimestamp
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    public enum DisbursementStatus {
        PENDING, PROCESSING, COMPLETED, FAILED, CANCELLED
    }
}