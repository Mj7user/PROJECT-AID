package com.cognizant.disbursementservice.dto;
import com.cognizant.disbursementservice.entity.Payment; import lombok.*; import java.time.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class PaymentResponseDto { private Long paymentId; private Long disbursementId; private Payment.PaymentMethod method; private LocalDate date; private Payment.PaymentStatus status; }
