package com.cognizant.ProgramAndScheme.controller;

import com.cognizant.ProgramAndScheme.dto.request.ProgramRequest;
import com.cognizant.ProgramAndScheme.dto.response.ProgramResponse;
import com.cognizant.ProgramAndScheme.service.ProgramService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/programs")
@RequiredArgsConstructor
public class ProgramController {

    private final ProgramService programService;

    @PostMapping
    public ResponseEntity<ProgramResponse> createProgram(
            @Valid @RequestBody ProgramRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(programService.createProgram(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProgramResponse> getProgramById(
            @PathVariable Long id
    ) {
        return ResponseEntity.ok(
                programService.getProgramById(id)
        );
    }

    @GetMapping
    public ResponseEntity<Page<ProgramResponse>> getAllPrograms(
            @PageableDefault(size = 20) Pageable pageable
    ) {
        return ResponseEntity.ok(
                programService.getAllPrograms(pageable)
        );
    }
}
