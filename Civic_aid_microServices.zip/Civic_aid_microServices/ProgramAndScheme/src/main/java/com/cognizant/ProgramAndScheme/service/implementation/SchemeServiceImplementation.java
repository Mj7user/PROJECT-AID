package com.cognizant.ProgramAndScheme.service.implementation;

import com.cognizant.ProgramAndScheme.dto.request.SchemeRequest;
import com.cognizant.ProgramAndScheme.dto.response.SchemeResponse;
import com.cognizant.ProgramAndScheme.entity.Program;
import com.cognizant.ProgramAndScheme.entity.Scheme;
import com.cognizant.ProgramAndScheme.exception.ResourceNotFoundException;
import com.cognizant.ProgramAndScheme.repository.ProgramRepository;
import com.cognizant.ProgramAndScheme.repository.SchemeRepository;
import com.cognizant.ProgramAndScheme.service.SchemeService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SchemeServiceImplementation implements SchemeService {

    private final SchemeRepository schemeRepository;
    private final ProgramRepository programRepository;

    @Override
    @Transactional
    public SchemeResponse createScheme(SchemeRequest request) {

        Program program = programRepository.findById(request.getProgramId())
                .orElseThrow(() ->
                        new ResourceNotFoundException("Program", request.getProgramId()));

        Scheme scheme = Scheme.builder()
                .program(program)
                .title(request.getTitle())
                .description(request.getDescription())
                .eligibilityCriteria(request.getEligibilityCriteria())
                .status(request.getStatus())
                .build();

        return map(schemeRepository.save(scheme));
    }

    @Override
    public SchemeResponse getSchemeById(Long id) {
        return map(
                schemeRepository.findById(id)
                        .orElseThrow(() ->
                                new ResourceNotFoundException("Scheme", id))
        );
    }

    @Override
    public Page<SchemeResponse> getAllSchemes(Pageable pageable) {
        return schemeRepository.findAll(pageable)
                .map(this::map);
    }

    @Override
    public List<SchemeResponse> getSchemesByProgram(Long programId) {
        return schemeRepository.findByProgram_ProgramId(programId)
                .stream()
                .map(this::map)
                .toList();
    }

    @Override
    @Transactional
    public SchemeResponse updateScheme(Long id, SchemeRequest request) {

        Scheme scheme = schemeRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Scheme", id));

        Program program = programRepository.findById(request.getProgramId())
                .orElseThrow(() ->
                        new ResourceNotFoundException("Program", request.getProgramId()));

        scheme.setProgram(program);
        scheme.setTitle(request.getTitle());
        scheme.setDescription(request.getDescription());
        scheme.setEligibilityCriteria(request.getEligibilityCriteria());
        scheme.setStatus(request.getStatus());

        return map(schemeRepository.save(scheme));
    }

    @Override
    @Transactional
    public void updateSchemeStatus(Long id, Scheme.SchemeStatus status) {
        Scheme scheme = schemeRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Scheme", id));

        scheme.setStatus(status);
        schemeRepository.save(scheme);
    }

    @Override
    @Transactional
    public void deleteScheme(Long id) {
        schemeRepository.delete(
                schemeRepository.findById(id)
                        .orElseThrow(() ->
                                new ResourceNotFoundException("Scheme", id))
        );
    }


    private SchemeResponse map(Scheme s) {
        return SchemeResponse.builder()
                .schemeId(s.getSchemeId())
                .programId(s.getProgram().getProgramId())
                .programTitle(s.getProgram().getTitle())
                .title(s.getTitle())
                .description(s.getDescription())
                .eligibilityCriteria(s.getEligibilityCriteria())
                .status(s.getStatus())
                .createdAt(s.getCreatedAt())
                .updatedAt(s.getUpdatedAt())
                .build();
    }
}
