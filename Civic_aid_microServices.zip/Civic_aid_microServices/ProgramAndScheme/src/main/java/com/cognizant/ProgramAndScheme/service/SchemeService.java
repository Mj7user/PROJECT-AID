package com.cognizant.ProgramAndScheme.service;

import com.cognizant.ProgramAndScheme.dto.request.SchemeRequest;
import com.cognizant.ProgramAndScheme.dto.response.SchemeResponse;
import com.cognizant.ProgramAndScheme.entity.Scheme;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface SchemeService {

    SchemeResponse createScheme(SchemeRequest request);

    SchemeResponse getSchemeById(Long id);

    Page<SchemeResponse> getAllSchemes(Pageable pageable);

    List<SchemeResponse> getSchemesByProgram(Long programId);

    SchemeResponse updateScheme(Long id, SchemeRequest request);

    void updateSchemeStatus(Long id, Scheme.SchemeStatus status);

    void deleteScheme(Long id);
}