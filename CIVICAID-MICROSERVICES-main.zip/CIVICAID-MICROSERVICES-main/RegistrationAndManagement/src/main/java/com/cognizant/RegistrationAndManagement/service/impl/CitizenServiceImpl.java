package com.cognizant.RegistrationAndManagement.service.impl;

import com.cognizant.RegistrationAndManagement.entity.Citizen;
import com.cognizant.RegistrationAndManagement.exception.BusinessException;
import com.cognizant.RegistrationAndManagement.exception.ResourceNotFoundException;
import com.cognizant.RegistrationAndManagement.repository.CitizenRepository;
import com.cognizant.RegistrationAndManagement.request.CitizenRequest;
import com.cognizant.RegistrationAndManagement.response.CitizenResponse;
import com.cognizant.RegistrationAndManagement.service.CitizenService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class CitizenServiceImpl implements CitizenService {

    private final CitizenRepository citizenRepository;

    @Override
    @Transactional
    public CitizenResponse registerCitizen(CitizenRequest request) {

        if (citizenRepository.existsByUserId(request.getUserId())) {
            throw new BusinessException(
                    "Citizen profile already exists for user"
            );
        }

        Citizen citizen = Citizen.builder()
                .name(request.getName())
                .dob(request.getDob())
                .gender(request.getGender())
                .address(request.getAddress())
                .contactInfo(request.getContactInfo())
                .userId(request.getUserId())
                .status(Citizen.CitizenStatus.PENDING)
                .build();

        return mapToResponse(citizenRepository.save(citizen));
    }

    @Override
    public CitizenResponse getCitizenById(Long id) {
        return mapToResponse(
                citizenRepository.findById(id)
                        .orElseThrow(() ->
                                new ResourceNotFoundException("Citizen", id))
        );
    }

    @Override
    @Transactional
    public CitizenResponse updateCitizen(Long id, CitizenRequest request) {

        Citizen citizen = citizenRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Citizen", id));

        citizen.setName(request.getName());
        citizen.setDob(request.getDob());
        citizen.setGender(request.getGender());
        citizen.setAddress(request.getAddress());
        citizen.setContactInfo(request.getContactInfo());

        return mapToResponse(citizenRepository.save(citizen));
    }

    @Override
    public Page<CitizenResponse> getAllCitizens(Pageable pageable) {
        return citizenRepository.findAll(pageable)
                .map(this::mapToResponse);
    }

    @Override
    public Page<CitizenResponse> searchCitizens(
            String search,
            Pageable pageable
    ) {
        return citizenRepository.searchByName(search, pageable)
                .map(this::mapToResponse);
    }

    @Override
    public Page<CitizenResponse> getCitizensByStatus(
            Citizen.CitizenStatus status,
            Pageable pageable
    ) {
        return citizenRepository.findByStatus(status, pageable)
                .map(this::mapToResponse);
    }

    @Override
    @Transactional
    public void updateCitizenStatus(
            Long id,
            Citizen.CitizenStatus status
    ) {
        Citizen citizen = citizenRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Citizen", id));

        citizen.setStatus(status);
        citizenRepository.save(citizen);
    }


    private CitizenResponse mapToResponse(Citizen c) {
        return CitizenResponse.builder()
                .citizenId(c.getCitizenId())
                .name(c.getName())
                .dob(c.getDob())
                .gender(c.getGender())
                .address(c.getAddress())
                .contactInfo(c.getContactInfo())
                .status(c.getStatus())
                .userId(c.getUserId())
                .createdAt(c.getCreatedAt())
                .updatedAt(c.getUpdatedAt())
                .build();
    }
}
