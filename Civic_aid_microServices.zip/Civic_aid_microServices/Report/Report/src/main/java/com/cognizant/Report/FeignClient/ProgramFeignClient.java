package com.cognizant.Report.FeignClient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Map;

@FeignClient(name = "program-service", path = "/programs")
public interface ProgramFeignClient {

    @GetMapping("/stats")
    Map<String, Object> getProgramStats();
}
