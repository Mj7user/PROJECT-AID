export type EntityType = 'APPLICATION' | 'PROGRAM' | 'CITIZEN' | 'DISBURSEMENT' | 'PAYMENT';
export type ComplianceResult = 'COMPLIANT' | 'NON_COMPLIANT' | 'UNDER_REVIEW' | 'PENDING';
export type AuditStatus = 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED' | 'PENDING_REVIEW' | 'CLOSED';

export interface ComplianceRecordRequest {
  entityId: number;
  entityType: EntityType;
  result: ComplianceResult;
  notes?: string;
}

export interface ComplianceRecordResponse {
  complianceId: number;
  entityId: number;
  entityType: EntityType;
  result: ComplianceResult;
  notes: string;
  reviewedById: number;
  createdAt: string;
}

export interface AuditRequest {
  scope: string;
  findings?: string;
  status: AuditStatus;
}

export interface AuditResponse {
  auditId: number;
  officerId: number;
  scope: string;
  findings: string;
  status: AuditStatus;
  createdAt: string;
  updatedAt: string;
}
