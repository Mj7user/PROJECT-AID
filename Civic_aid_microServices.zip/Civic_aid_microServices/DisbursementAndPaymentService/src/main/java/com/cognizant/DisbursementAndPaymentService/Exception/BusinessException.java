package com.cognizant.DisbursementAndPaymentService.Exception;

public class BusinessException extends RuntimeException {
    public BusinessException(String message) {
        super(message);
    }
}
