package com.cognizant.ComplianceAndAuditService.Service.Implementation;

import com.cognizant.ComplianceAndAuditService.Request.AuditRequest;
import com.cognizant.ComplianceAndAuditService.Response.AuditResponse;
import com.cognizant.ComplianceAndAuditService.Entity.Audit;
import com.cognizant.ComplianceAndAuditService.Exception.ResourceNotFoundException;
import com.cognizant.ComplianceAndAuditService.Repository.AuditRepository;
import com.cognizant.ComplianceAndAuditService.Service.AuditService;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Transactional
public class AuditServiceImpl implements AuditService {

    private final AuditRepository auditRepository;

    @Override
    public AuditResponse createAudit(Long officerId, AuditRequest request) {

        Audit audit = Audit.builder()
                .officerId(officerId)
                .scope(request.getScope())
                .findings(request.getFindings())
                .status(request.getStatus())
                .build();

        return map(auditRepository.save(audit));
    }

    @Override
    public AuditResponse getById(Long auditId) {
        return map(fetchAudit(auditId));
    }

    @Override
    public Page<AuditResponse> getAll(Pageable pageable) {
        return auditRepository.findAll(pageable)
                .map(this::map);
    }

    @Override
    public Page<AuditResponse> getByOfficer(Long officerId, Pageable pageable) {
        return auditRepository.findByOfficerId(officerId, pageable)
                .map(this::map);
    }

    @Override
    public Page<AuditResponse> getByStatus(
            Audit.AuditStatus status, Pageable pageable) {

        return auditRepository.findByStatus(status, pageable)
                .map(this::map);
    }

    private Audit fetchAudit(Long id) {
        return auditRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Audit", id));
    }

    private AuditResponse map(Audit a) {
        return AuditResponse.builder()
                .auditId(a.getAuditId())
                .officerId(a.getOfficerId())
                .scope(a.getScope())
                .findings(a.getFindings())
                .status(a.getStatus())
                .createdAt(a.getCreatedAt())
                .updatedAt(a.getUpdatedAt())
                .build();
    }
}