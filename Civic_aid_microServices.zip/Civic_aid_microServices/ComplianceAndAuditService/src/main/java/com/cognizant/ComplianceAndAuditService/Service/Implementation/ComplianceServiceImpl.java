package com.cognizant.ComplianceAndAuditService.Service.Implementation;

import com.cognizant.ComplianceAndAuditService.Request.ComplianceRecordRequest;
import com.cognizant.ComplianceAndAuditService.Response.ComplianceRecordResponse;
import com.cognizant.ComplianceAndAuditService.Entity.ComplianceRecord;
import com.cognizant.ComplianceAndAuditService.Exception.ResourceNotFoundException;
import com.cognizant.ComplianceAndAuditService.Repository.ComplianceRecordRepository;
import com.cognizant.ComplianceAndAuditService.Service.ComplianceService;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class ComplianceServiceImpl implements ComplianceService {

    private final ComplianceRecordRepository complianceRepository;

    @Override
    public ComplianceRecordResponse createRecord(
            Long reviewerId,
            ComplianceRecordRequest request) {

        ComplianceRecord record = ComplianceRecord.builder()
                .entityId(request.getEntityId())
                .entityType(request.getEntityType())
                .result(request.getResult())
                .notes(request.getNotes())
                .reviewedById(reviewerId)
                .build();

        return map(complianceRepository.save(record));
    }

    @Override
    public ComplianceRecordResponse getById(Long recordId) {
        return map(fetchRecord(recordId));
    }

    @Override
    public List<ComplianceRecordResponse> getByEntity(
            Long entityId,
            ComplianceRecord.EntityType entityType) {

        return complianceRepository
                .findByEntityIdAndEntityType(entityId, entityType)
                .stream()
                .map(this::map)
                .toList();
    }

    @Override
    public Page<ComplianceRecordResponse> getByResult(
            ComplianceRecord.ComplianceResult result,
            Pageable pageable) {

        return complianceRepository.findByResult(result, pageable)
                .map(this::map);
    }

    @Override
    public Page<ComplianceRecordResponse> getAll(Pageable pageable) {
        return complianceRepository.findAll(pageable)
                .map(this::map);
    }

    private ComplianceRecord fetchRecord(Long id) {
        return complianceRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Compliance Record", id));
    }

    private ComplianceRecordResponse map(ComplianceRecord c) {
        return ComplianceRecordResponse.builder()
                .complianceId(c.getComplianceId())
                .entityId(c.getEntityId())
                .entityType(c.getEntityType())
                .result(c.getResult())
                .notes(c.getNotes())
                .reviewedById(c.getReviewedById())
                .createdAt(c.getCreatedAt())
                .build();
    }
}