package com.cognizant.reportservice.dto;
import com.cognizant.reportservice.entity.Report; import lombok.*; import java.time.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ReportResponseDto { private Long reportId; private Report.ReportScope scope; private String metrics; private LocalDate generatedDate; private LocalDateTime createdAt; }
