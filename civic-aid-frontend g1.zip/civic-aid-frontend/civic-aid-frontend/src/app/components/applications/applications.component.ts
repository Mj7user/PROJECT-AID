import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApplicationService } from '../../services/application.service';
import { WelfareApplicationResponse, ApplicationStatus, WelfareApplicationRequest } from '../../models/application.model';

@Component({
  selector: 'app-applications',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './applications.component.html',
  styleUrls: ['./applications.component.scss']
})
export class ApplicationsComponent implements OnInit {
  applications: WelfareApplicationResponse[] = [];
  loading = true;
  showModal = false;
  showStatusModal = false;
  currentPage = 0;
  totalPages = 0;
  filterStatus: ApplicationStatus | '' = '';
  selectedApp: WelfareApplicationResponse | null = null;
  newStatus: ApplicationStatus = 'UNDER_REVIEW';
  statusRemarks = '';

  formData: WelfareApplicationRequest = { citizenId: 0, programId: 0, remarks: '' };
  statuses: ApplicationStatus[] = ['SUBMITTED', 'UNDER_REVIEW', 'ELIGIBLE', 'INELIGIBLE', 'APPROVED', 'REJECTED', 'DISBURSED', 'CLOSED'];
  error = '';
  success = '';

  constructor(private appService: ApplicationService) {}
  ngOnInit() { this.loadApplications(); }

  loadApplications() {
    this.loading = true;
    this.appService.getAllApplications(this.currentPage, 20, this.filterStatus || undefined).subscribe({
      next: (page) => { this.applications = page.content; this.totalPages = page.totalPages; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  openCreate() { this.formData = { citizenId: 0, programId: 0, remarks: '' }; this.error = ''; this.showModal = true; }

  submitApplication() {
    if (!this.formData.citizenId || !this.formData.programId) { this.error = 'Citizen ID and Program ID are required'; return; }
    this.appService.submitApplication(this.formData).subscribe({
      next: () => { this.showModal = false; this.success = 'Application submitted'; this.loadApplications(); setTimeout(() => this.success = '', 3000); },
      error: (err) => { this.error = err.error?.message || 'Failed to submit application'; }
    });
  }

  openStatusUpdate(app: WelfareApplicationResponse) { this.selectedApp = app; this.newStatus = app.status; this.statusRemarks = ''; this.showStatusModal = true; }

  updateStatus() {
    if (!this.selectedApp) return;
    this.appService.updateApplicationStatus(this.selectedApp.applicationId, this.newStatus, this.statusRemarks || undefined).subscribe({
      next: () => { this.showStatusModal = false; this.success = 'Status updated'; this.loadApplications(); setTimeout(() => this.success = '', 3000); },
      error: () => { this.error = 'Failed to update status'; }
    });
  }

  withdraw(id: number) {
    if (confirm('Withdraw this application?')) {
      this.appService.withdrawApplication(id).subscribe({ next: () => this.loadApplications() });
    }
  }

  onFilterChange() { this.currentPage = 0; this.loadApplications(); }

  getStatusClass(s: string): string {
    const m: Record<string, string> = { 'SUBMITTED': 'badge-info', 'UNDER_REVIEW': 'badge-warning', 'ELIGIBLE': 'badge-success', 'INELIGIBLE': 'badge-danger', 'APPROVED': 'badge-success', 'REJECTED': 'badge-danger', 'DISBURSED': 'badge-primary', 'CLOSED': 'badge-muted' };
    return m[s] || 'badge-muted';
  }

  formatDate(d: string): string { return d ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'; }
  prevPage() { if (this.currentPage > 0) { this.currentPage--; this.loadApplications(); } }
  nextPage() { if (this.currentPage < this.totalPages - 1) { this.currentPage++; this.loadApplications(); } }
}
