package com.cognizant.Notification.service;

import com.cognizant.Notification.dto.response.NotificationResponse;
import com.cognizant.Notification.entity.Notification;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface NotificationService {

    void sendNotification(
            Long recipientId,
            Long entityId,
            String message,
            Notification.NotificationCategory category
    );

    Page<NotificationResponse> getNotifications(
            Long recipientId,
            Pageable pageable
    );

    Page<NotificationResponse> getUnreadNotifications(
            Long recipientId,
            Pageable pageable
    );

    long getUnreadCount(Long recipientId);

    void markAsRead(Long notificationId);

    int markAllAsRead(Long recipientId);

    void deleteNotification(Long notificationId);
}
