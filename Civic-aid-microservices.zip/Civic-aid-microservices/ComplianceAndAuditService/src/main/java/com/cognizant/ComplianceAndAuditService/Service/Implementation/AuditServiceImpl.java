package com.cognizant.civicaid.service.impl;

import com.cognizant.civicaid.dto.request.AuditRequest;
import com.cognizant.civicaid.dto.response.AuditResponse;
import com.cognizant.civicaid.entity.Audit;
import com.cognizant.civicaid.entity.User;
import com.cognizant.civicaid.exception.ResourceNotFoundException;
import com.cognizant.civicaid.repository.AuditRepository;
import com.cognizant.civicaid.repository.UserRepository;
import com.cognizant.civicaid.service.AuditService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuditServiceImpl implements AuditService {

    private final AuditRepository auditRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public AuditResponse createAudit(Long officerId, AuditRequest request) {

        log.info("Creating audit | officerId={} | scope={}",
                officerId, request.getScope());

        User officer = userRepository.findById(officerId)
                .orElseThrow(() -> {
                    log.error("Officer not found | officerId={}", officerId);
                    return new ResourceNotFoundException("User", officerId);
                });

        Audit audit = Audit.builder()
                .officer(officer)
                .scope(request.getScope())
                .findings(request.getFindings())
                .status(request.getStatus() != null
                        ? request.getStatus()
                        : Audit.AuditStatus.IN_PROGRESS)
                .build();

        Audit savedAudit = auditRepository.save(audit);

        log.info("Audit created successfully | auditId={} | status={}",
                savedAudit.getAuditId(), savedAudit.getStatus());

        return mapToResponse(savedAudit);
    }

    @Override
    public AuditResponse getAuditById(Long id) {

        log.debug("Fetching audit | auditId={}", id);

        Audit audit = auditRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Audit not found | auditId={}", id);
                    return new ResourceNotFoundException("Audit", id);
                });

        return mapToResponse(audit);
    }

    @Override
    public Page<AuditResponse> getAllAudits(Pageable pageable) {

        log.debug("Fetching all audits | page={} | size={}",
                pageable.getPageNumber(), pageable.getPageSize());

        Page<AuditResponse> page =
                auditRepository.findAll(pageable).map(this::mapToResponse);

        log.info("Fetched {} audits", page.getTotalElements());
        return page;
    }

    @Override
    public Page<AuditResponse> getAuditsByOfficer(Long officerId, Pageable pageable) {

        log.debug("Fetching audits for officer | officerId={}", officerId);

        Page<AuditResponse> page =
                auditRepository.findByOfficer_UserId(officerId, pageable)
                        .map(this::mapToResponse);

        log.info("Fetched {} audits for officerId={}",
                page.getTotalElements(), officerId);

        return page;
    }

    @Override
    public Page<AuditResponse> getAuditsByStatus(
            Audit.AuditStatus status, Pageable pageable) {

        log.debug("Fetching audits by status | status={}", status);

        Page<AuditResponse> page =
                auditRepository.findByStatus(status, pageable)
                        .map(this::mapToResponse);

        log.info("Fetched {} audits with status={}",
                page.getTotalElements(), status);

        return page;
    }

    @Override
    @Transactional
    public AuditResponse updateAudit(Long id, AuditRequest request) {

        log.info("Updating audit | auditId={}", id);

        Audit audit = auditRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Audit not found for update | auditId={}", id);
                    return new ResourceNotFoundException("Audit", id);
                });

        audit.setScope(request.getScope());
        audit.setFindings(request.getFindings());

        if (request.getStatus() != null) {
            log.debug("Updating audit status | auditId={} | newStatus={}",
                    id, request.getStatus());
            audit.setStatus(request.getStatus());
        }

        Audit updatedAudit = auditRepository.save(audit);

        log.info("Audit updated successfully | auditId={} | status={}",
                updatedAudit.getAuditId(), updatedAudit.getStatus());

        return mapToResponse(updatedAudit);
    }

    private AuditResponse mapToResponse(Audit a) {
        return AuditResponse.builder()
                .auditId(a.getAuditId())
                .officerId(a.getOfficer().getUserId())
                .officerName(a.getOfficer().getName())
                .scope(a.getScope())
                .findings(a.getFindings())
                .date(a.getDate())
                .status(a.getStatus())
                .updatedAt(a.getUpdatedAt())
                .build();
    }
}