package com.cognizant.DisbursementAndPaymentService.Response;


import lombok.*;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WelfareApplicationResponse {

    private Long applicationId;
    private Long citizenId;
    private Long programId;
    private Long schemeId;
    private LocalDateTime submittedDate;
    private String status;
    private String remarks;
    private LocalDateTime updatedAt;
}